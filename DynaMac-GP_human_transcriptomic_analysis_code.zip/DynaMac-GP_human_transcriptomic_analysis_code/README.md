# DynaMac-GP human transcriptomic analysis code

This package contains the quality-control, annotation, donor-level pseudobulk,
statistical-analysis and Figure 4 plotting code used for the exploratory human
transcriptomic analyses in DynaMac-GP. Raw and processed data are not included.

## Datasets

- GSE205389, human TMJ synovial bulk RNA-sequencing data
- GSE216651, human knee infrapatellar fat pad and synovial single-cell
  RNA-sequencing data

The public source files should be obtained independently from GEO and placed at:

```text
data/GSE205389/GSE205389_mRNA_Expression_Profiling.xlsx
data/GSE205389/GSE205389_family.soft.gz
data/GSE216651/GSE216651_RAW.tar
```

## Core entry points

```text
scripts/01_bulk_analysis.py
scripts/02_single_cell_analysis.py
scripts/03_make_figure4.R
run_analysis.R
```

The scripts under `workflow/sc_revision/` implement the steps called by the
entry points. They include donor-specific quality control and doublet removal,
cell annotation, immune-cell refinement, donor-level pseudobulk analysis and
preparation of Figure 4 source data.

## Environment

```bash
conda env create -f environment.yml
conda activate tmj-transcriptomics
```

Alternatively, install the Python dependencies listed in `requirements.txt`
and the R packages `ggplot2`, `patchwork` and `scales`.

## Run

Run the complete analysis from the package root:

```bash
Rscript run_analysis.R
```

After the analysis has generated the required source tables, Figure 4 can be
regenerated separately with:

```bash
Rscript scripts/03_make_figure4.R
```

Cells are used as visualization units only. Donors are treated as independent
biological replicates in the single-cell pseudobulk comparisons.
