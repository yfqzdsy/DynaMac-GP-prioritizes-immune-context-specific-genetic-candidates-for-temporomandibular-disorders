#!/usr/bin/env Rscript

# One-command entry point for the complete human transcriptomic workflow.

if (!file.exists("scripts/01_bulk_analysis.py")) {
  stop("Run this file from the repository root.")
}

python <- Sys.getenv("PYTHON", unset = "python3")
commands <- list(
  c(python, "scripts/01_bulk_analysis.py"),
  c(python, "scripts/02_single_cell_analysis.py"),
  c("Rscript", "scripts/03_make_figure4.R")
)

for (command in commands) {
  message("\n> ", paste(command, collapse = " "))
  status <- system2(command[[1]], command[-1])
  if (!identical(status, 0L)) stop("Analysis stopped with exit status ", status)
}

message("\nAnalysis complete.")
