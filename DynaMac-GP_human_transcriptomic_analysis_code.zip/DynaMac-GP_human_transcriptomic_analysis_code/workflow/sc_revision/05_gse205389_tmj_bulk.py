#!/usr/bin/env python3
"""Candidate-gene analysis in human TMJ synovium from GSE205389.

The comparison is five TMJOA samples versus five reducible anterior disc
displacement samples. The latter are disease controls, not healthy controls.
The deposited study provides Cuffdiff FPKM and non-integer estimated counts;
therefore the prespecified candidate analysis uses log2(FPKM + 1), exact label
permutation tests, effect sizes, and secondary Welch tests.
"""

from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats


GENE_ORDER = ["APOBEC3G", "GTF2H1", "XRCC1", "C10orf32/BORCS7", "WBP1L", "H1F0", "GALT"]


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input",
        type=Path,
        default=root / "outputs/sc_revision/01_feasibility/GSE205389_candidate_expression.csv",
    )
    parser.add_argument("--outdir", type=Path, default=root / "outputs/sc_revision/05_gse205389_bulk")
    return parser.parse_args()


def bh_adjust(pvalues: np.ndarray) -> np.ndarray:
    values = np.asarray(pvalues, dtype=float)
    order = np.argsort(values)
    ranked = values[order]
    adjusted = ranked * len(values) / np.arange(1, len(values) + 1)
    adjusted = np.minimum.accumulate(adjusted[::-1])[::-1]
    result = np.empty_like(adjusted)
    result[order] = np.clip(adjusted, 0, 1)
    return result


def exact_two_sided_p(values: np.ndarray, n_case: int, observed_case: tuple[int, ...]) -> float:
    observed_control = [index for index in range(len(values)) if index not in observed_case]
    observed = abs(values[list(observed_case)].mean() - values[observed_control].mean())
    permuted = []
    for case_indices in itertools.combinations(range(len(values)), n_case):
        control_indices = [index for index in range(len(values)) if index not in case_indices]
        permuted.append(abs(values[list(case_indices)].mean() - values[control_indices].mean()))
    return float(np.mean(np.asarray(permuted) >= observed - 1e-12))


def welch_ci(case: np.ndarray, control: np.ndarray) -> tuple[float, float, float]:
    effect = float(case.mean() - control.mean())
    var_case = case.var(ddof=1)
    var_control = control.var(ddof=1)
    se = float(np.sqrt(var_case / len(case) + var_control / len(control)))
    numerator = (var_case / len(case) + var_control / len(control)) ** 2
    denominator = (var_case / len(case)) ** 2 / (len(case) - 1) + (var_control / len(control)) ** 2 / (
        len(control) - 1
    )
    dof = float(numerator / denominator) if denominator > 0 else len(case) + len(control) - 2
    critical = float(stats.t.ppf(0.975, dof))
    return effect, effect - critical * se, effect + critical * se


def main() -> None:
    args = parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    frame = pd.read_csv(args.input)
    frame["log2_fpkm_plus_1"] = np.log2(frame["FPKM"].astype(float) + 1.0)
    frame["group_label"] = frame["condition"].map(
        {"TMJOA": "TMJOA", "disc_displacement_control": "Disc displacement control"}
    )
    frame.to_csv(args.outdir / "candidate_sample_expression.csv", index=False)

    rows: list[dict[str, object]] = []
    for gene in GENE_ORDER:
        gene_frame = frame[frame["priority_gene"] == gene].copy()
        gene_frame = gene_frame.sort_values(["condition", "sample"]).reset_index(drop=True)
        values = gene_frame["log2_fpkm_plus_1"].to_numpy(float)
        case_indices = tuple(np.flatnonzero(gene_frame["condition"].eq("TMJOA").to_numpy()))
        case = values[list(case_indices)]
        control_indices = [index for index in range(len(values)) if index not in case_indices]
        control = values[control_indices]
        effect, ci_low, ci_high = welch_ci(case, control)
        welch = stats.ttest_ind(case, control, equal_var=False)
        mann_whitney = stats.mannwhitneyu(case, control, alternative="two-sided")
        rows.append(
            {
                "gene": gene,
                "feature_symbol": gene_frame["feature_symbol"].iloc[0],
                "ensembl_id": gene_frame["ensembl_id"].iloc[0],
                "control_mean_fpkm": float(gene_frame.loc[control_indices, "FPKM"].mean()),
                "tmjoa_mean_fpkm": float(gene_frame.loc[list(case_indices), "FPKM"].mean()),
                "control_mean_log2_fpkm_plus_1": float(control.mean()),
                "tmjoa_mean_log2_fpkm_plus_1": float(case.mean()),
                "tmjoa_minus_control_log2_expression": effect,
                "effect_ci95_low": ci_low,
                "effect_ci95_high": ci_high,
                "exact_two_sided_permutation_p": exact_two_sided_p(values, 5, case_indices),
                "welch_t_p_secondary": float(welch.pvalue),
                "mann_whitney_p_secondary": float(mann_whitney.pvalue),
                "n_tmjoa": 5,
                "n_disc_displacement_control": 5,
                "inference_unit": "independent human sample",
            }
        )
    results = pd.DataFrame(rows)
    for column in ["exact_two_sided_permutation_p", "welch_t_p_secondary", "mann_whitney_p_secondary"]:
        results[f"{column}_bh_fdr"] = bh_adjust(results[column].to_numpy())
    results.to_csv(args.outdir / "candidate_effects_and_tests.csv", index=False)

    parameters = {
        "dataset": "GSE205389",
        "tissue": "human temporomandibular joint synovium",
        "comparison": "TMJOA (n=5) versus reducible anterior disc displacement (n=5)",
        "control_boundary": "disc displacement controls are not healthy controls",
        "deposited_processing": "hg19 alignment with HISAT2; Cuffdiff FPKM and estimated counts",
        "analysis_scale": "log2(FPKM + 1)",
        "primary_test": "exact two-sided permutation of the 5-versus-5 sample labels",
        "secondary_tests": "Welch t test and Mann-Whitney U test",
        "multiple_testing": "Benjamini-Hochberg across the seven prespecified genes",
        "interpretation": "independent TMJ tissue-level contextual support; not cell-type-specific evidence",
    }
    (args.outdir / "parameters.json").write_text(json.dumps(parameters, indent=2), encoding="utf-8")
    print(results.to_string(index=False))


if __name__ == "__main__":
    main()
