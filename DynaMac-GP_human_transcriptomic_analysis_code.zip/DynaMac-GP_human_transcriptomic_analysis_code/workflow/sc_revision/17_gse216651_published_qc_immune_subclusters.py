#!/usr/bin/env python3
"""Immune subclustering for the strict-QC GSE216651 primary analysis.

The parent atlas was generated with the QC and dimension-reduction settings
reported by Raut et al. (Commun Biol 2025).  This script keeps the same 2,000
HVG, 20-PC, Harmony, and resolution-0.5 settings within the T/NK and
monocyte/DC compartments. Harmony coordinates are used only for graph
construction and visualization; the raw-count layer remains unchanged.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import scanpy as sc
from scipy import sparse


RANDOM_SEED = 20260809
SUBSETS = {
    "T_NK": {"parent_clusters": {"8"}},
    "Monocyte_DC": {"parent_clusters": {"3"}},
}
MARKER_PANELS = {
    "T_NK": {
        "Pan_T": ["CD3D", "CD3E", "TRAC", "LTB"],
        "CD4_T": ["IL7R", "CCR7", "MAL", "LTB"],
        "CD8_T": ["CD8A", "CD8B", "CCL5", "GZMK"],
        "NK": ["NKG7", "GNLY", "KLRD1", "PRF1"],
        "Cytotoxic": ["CCL5", "NKG7", "GZMB", "PRF1"],
    },
    "Monocyte_DC": {
        "Pan_myeloid": ["LYZ", "FCER1G", "TYROBP", "CTSS"],
        "Classical_monocyte": ["FCN1", "S100A8", "S100A9", "CTSS"],
        "DC": ["CD1C", "FCER1A", "CLEC10A", "CST3"],
        "Antigen_presentation": ["HLA-DRA", "CD74", "HLA-DPA1", "HLA-DPB1"],
        "Macrophage": ["C1QA", "C1QB", "FOLR2", "MRC1", "SPP1"],
    },
}


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--h5ad",
        type=Path,
        default=root / "outputs/sc_revision/13_gse216651_published_qc/objects/GSE216651_preliminary_processed.h5ad",
    )
    parser.add_argument(
        "--outdir",
        type=Path,
        default=root / "outputs/sc_revision/15_gse216651_published_qc_immune_subclusters",
    )
    return parser.parse_args()


def mean_fraction(matrix: sparse.spmatrix | np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    return np.asarray(matrix.mean(axis=0)).ravel(), np.asarray((matrix > 0).mean(axis=0)).ravel()


def marker_table(adata: ad.AnnData, genes: list[str], key: str) -> pd.DataFrame:
    genes = [gene for gene in genes if gene in adata.var_names]
    rows: list[dict[str, object]] = []
    for cluster, indices in adata.obs.groupby(key, observed=True).groups.items():
        subset = adata[indices, genes]
        mean, fraction = mean_fraction(subset.X)
        for gene, avg, detected in zip(genes, mean, fraction, strict=True):
            rows.append({
                "subcluster": str(cluster), "gene": gene, "n_cells": int(subset.n_obs),
                "mean_log_normalized_expression": float(avg), "detected_fraction": float(detected),
            })
    return pd.DataFrame(rows)


def process(parent: ad.AnnData, name: str, clusters: set[str], outdir: Path) -> dict[str, object]:
    mask = parent.obs["leiden_0_6"].astype(str).isin(clusters)
    source = parent[mask].copy()
    counts = source.layers["counts"]
    counts = sparse.csr_matrix(counts) if not sparse.issparse(counts) else counts.tocsr()
    subset = ad.AnnData(X=counts.copy(), obs=source.obs.copy(), var=source.var.copy())
    subset.layers["counts"] = counts.copy()

    sc.pp.normalize_total(subset, target_sum=10_000)
    sc.pp.log1p(subset)
    sc.pp.highly_variable_genes(
        subset, n_top_genes=min(2_000, subset.n_vars), flavor="seurat", batch_key="sample"
    )
    sc.pp.pca(subset, n_comps=20, use_highly_variable=True, random_state=RANDOM_SEED)
    sc.external.pp.harmony_integrate(
        subset, key="sample", basis="X_pca", adjusted_basis="X_pca_harmony", random_state=RANDOM_SEED
    )
    sc.pp.neighbors(
        subset, n_neighbors=15, n_pcs=20, use_rep="X_pca_harmony", random_state=RANDOM_SEED
    )
    key = f"{name}_leiden"
    sc.tl.leiden(
        subset, resolution=0.5, key_added=key, random_state=RANDOM_SEED,
        flavor="igraph", n_iterations=2,
    )
    sc.tl.umap(subset, random_state=RANDOM_SEED)
    sc.tl.rank_genes_groups(subset, groupby=key, method="wilcoxon", pts=True)

    marker_results = subset.uns["rank_genes_groups"]
    top_rows: list[dict[str, object]] = []
    for group in marker_results["names"].dtype.names:
        for rank in range(min(50, len(marker_results["names"][group]))):
            top_rows.append({
                "subcluster": str(group), "rank": rank + 1,
                "gene": str(marker_results["names"][group][rank]),
                "score": float(marker_results["scores"][group][rank]),
                "logfoldchange": float(marker_results["logfoldchanges"][group][rank]),
                "pval_adj": float(marker_results["pvals_adj"][group][rank]),
            })
    pd.DataFrame(top_rows).to_csv(outdir / f"{name}_subcluster_top_markers.csv", index=False)
    genes = list(dict.fromkeys(g for panel in MARKER_PANELS[name].values() for g in panel))
    marker_table(subset, genes, key).to_csv(outdir / f"{name}_subcluster_marker_expression.csv", index=False)

    donor_counts = (
        subset.obs.groupby(["sample", "condition", key], observed=True).size().rename("n_cells")
        .reset_index().rename(columns={key: "subcluster"})
    )
    donor_counts.to_csv(outdir / f"{name}_subcluster_counts_by_donor.csv", index=False)
    metadata = subset.obs[["gsm", "sample", "condition", key]].copy()
    metadata["UMAP1"] = subset.obsm["X_umap"][:, 0]
    metadata["UMAP2"] = subset.obsm["X_umap"][:, 1]
    metadata.rename(columns={key: "subcluster"}).to_csv(
        outdir / f"{name}_subcluster_metadata_umap.csv.gz", compression="gzip"
    )
    subset.write_h5ad(outdir / f"{name}_subclustered.h5ad", compression="gzip")
    return {
        "subset": name, "parent_clusters": sorted(clusters), "n_cells": int(subset.n_obs),
        "n_subclusters": int(subset.obs[key].nunique()), "n_hvg": 2_000, "n_pcs": 20,
        "resolution": 0.5,
    }


def main() -> None:
    args = parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    parent = ad.read_h5ad(args.h5ad)
    summaries = [process(parent, name, cfg["parent_clusters"], args.outdir) for name, cfg in SUBSETS.items()]
    parameters = {
        "input_h5ad": args.h5ad.as_posix(),
        "reference": "Raut et al., Communications Biology 2025, DOI 10.1038/s42003-025-08586-8",
        "scope": "strict-QC primary human transcriptomic analysis",
        "random_seed": RANDOM_SEED,
        "normalization": "library-size normalization to 10,000 counts followed by log1p",
        "feature_selection": "2,000 HVGs, Scanpy seurat flavor with donor batch key",
        "integration_boundary": "Harmony used only for clustering and visualization",
        "cell_level_disease_testing": "none",
        "subsets": summaries,
        "marker_panels": MARKER_PANELS,
    }
    (args.outdir / "parameters.json").write_text(json.dumps(parameters, indent=2), encoding="utf-8")
    print(pd.DataFrame(summaries).to_string(index=False))


if __name__ == "__main__":
    main()
