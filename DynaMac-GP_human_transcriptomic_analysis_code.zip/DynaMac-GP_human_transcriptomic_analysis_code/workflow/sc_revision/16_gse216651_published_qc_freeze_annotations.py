#!/usr/bin/env python3
"""Freeze broad labels for the strict-QC GSE216651 primary analysis.

The input object uses the QC and dimension-reduction settings reported by the
Raut et al. secondary analysis (Commun Biol 2025), except that Scrublet is used
per donor instead of DoubletFinder. Labels are assigned by manual review of
data-driven markers and canonical panels. No disease-group test is performed.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
from scipy import sparse


CANDIDATES = ["APOBEC3G", "GTF2H1", "XRCC1", "BORCS7", "WBP1L", "H1F0", "GALT"]

CLUSTER_ANNOTATIONS = {
    "0": ("Fibroblast_PRG4", "CRTAC1;PRG4;HTRA1;FN1;CLU"),
    "1": ("Fibroblast_COL14A1", "CXCL12;LUM;COL14A1;DPT;COL1A2"),
    "2": ("Macrophage", "C1QA;C1QB;C1QC;FOLR2;CD163"),
    "3": ("Monocyte_DC", "LYZ;FCER1G;HLA-DRA;CD74;CXCL8"),
    "4": ("Fibroblast_CXCL14", "C3;APOD;DCN;CFD;CXCL14"),
    "5": ("Fibroblast_matrix", "MFAP5;DCN;MMP2;FBN1;FBLN1"),
    "6": ("Pericyte_SMC", "TAGLN;MYL9;ACTA2;NOTCH3;MCAM"),
    "7": ("Endothelial", "PECAM1;VWF;PLVAP;EMCN;ACKR1"),
    "8": ("T_NK", "PTPRC;IL32;CD3E;CD52;CST7"),
}

MARKERS = [
    "DCN", "PRG4", "CXCL14", "COL14A1", "PECAM1", "VWF", "PLVAP",
    "RGS5", "ACTA2", "C1QA", "FOLR2", "CD163", "LYZ", "HLA-DRA",
    "CD74", "FCN1", "CD3D", "CD8A", "NKG7", "GNLY", "TPSAB1", "CPA3",
]


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--h5ad",
        type=Path,
        default=root / "outputs/sc_revision/13_gse216651_published_qc/objects/GSE216651_preliminary_processed.h5ad",
    )
    parser.add_argument(
        "--outdir",
        type=Path,
        default=root / "outputs/sc_revision/14_gse216651_published_qc_labels",
    )
    return parser.parse_args()


def mean_fraction(matrix: sparse.spmatrix | np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    return np.asarray(matrix.mean(axis=0)).ravel(), np.asarray((matrix > 0).mean(axis=0)).ravel()


def expression_table(adata: ad.AnnData, genes: list[str], groups: list[str]) -> pd.DataFrame:
    genes = [gene for gene in genes if gene in adata.var_names]
    rows: list[dict[str, object]] = []
    for values, indices in adata.obs.groupby(groups, observed=True).groups.items():
        if not isinstance(values, tuple):
            values = (values,)
        subset = adata[indices, genes]
        mean, fraction = mean_fraction(subset.X)
        prefix = dict(zip(groups, values, strict=True))
        for gene, avg, detected in zip(genes, mean, fraction, strict=True):
            rows.append(
                {
                    **prefix,
                    "gene": gene,
                    "n_cells": int(subset.n_obs),
                    "mean_log_normalized_expression": float(avg),
                    "detected_fraction": float(detected),
                }
            )
    return pd.DataFrame(rows)


def main() -> None:
    args = parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    adata = ad.read_h5ad(args.h5ad)
    key = "leiden_0_6"
    observed = set(adata.obs[key].astype(str).unique())
    if observed != set(CLUSTER_ANNOTATIONS):
        raise ValueError(f"Unexpected clusters: {sorted(observed)}")

    label_map = {cluster: value[0] for cluster, value in CLUSTER_ANNOTATIONS.items()}
    adata.obs["cell_type"] = adata.obs[key].astype(str).map(label_map).astype("category")
    top = pd.read_csv(args.h5ad.parents[1] / "tables/provisional_cluster_top_markers.csv.gz")
    mapping_rows: list[dict[str, object]] = []
    for cluster, (label, evidence) in CLUSTER_ANNOTATIONS.items():
        ranked = top[top["group"].astype(str).eq(cluster)].sort_values("scores", ascending=False)
        mapping_rows.append(
            {
                "leiden_cluster": cluster,
                "cell_type": label,
                "n_cells": int(adata.obs[key].astype(str).eq(cluster).sum()),
                "canonical_marker_evidence": evidence,
                "top_15_data_driven_markers": ";".join(ranked["names"].astype(str).head(15)),
                "annotation_method": "manual review of canonical and data-driven markers",
            }
        )
    pd.DataFrame(mapping_rows).to_csv(args.outdir / "cluster_to_cell_type_mapping.csv", index=False)

    metadata = adata.obs[["gsm", "sample", "condition", key, "cell_type"]].copy()
    metadata["UMAP1"] = adata.obsm["X_umap"][:, 0]
    metadata["UMAP2"] = adata.obsm["X_umap"][:, 1]
    metadata.to_csv(args.outdir / "cell_metadata_with_frozen_labels.csv.gz", compression="gzip")
    counts = (
        adata.obs.groupby(["sample", "condition", "cell_type"], observed=True)
        .size().rename("n_cells").reset_index()
    )
    counts.to_csv(args.outdir / "cell_counts_by_donor_and_type.csv", index=False)
    expression_table(adata, MARKERS, ["cell_type"]).to_csv(
        args.outdir / "canonical_marker_dotplot_source.csv", index=False
    )
    expression_table(adata, CANDIDATES, ["sample", "condition", "cell_type"]).to_csv(
        args.outdir / "candidate_expression_by_donor_and_cell_type.csv", index=False
    )

    parameters = {
        "input_h5ad": args.h5ad.as_posix(),
        "qc_source": "Raut et al., Communications Biology 2025, DOI 10.1038/s42003-025-08586-8",
        "scope": "strict-QC primary human transcriptomic analysis",
        "annotation_boundary": "marker-supported labels were re-frozen for this QC-specific clustering",
        "disease_testing": "none",
    }
    (args.outdir / "parameters.json").write_text(json.dumps(parameters, indent=2), encoding="utf-8")
    print(counts.to_string(index=False))


if __name__ == "__main__":
    main()
