#!/usr/bin/env python3
"""Freeze marker-reviewed immune labels for the strict-QC primary analysis."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import anndata as ad
import pandas as pd


T_NK_MAP = {
    "0": "CD4_T",
    "1": "NK",
    "2": "CD8_T",
    "3": "Cycling_CD8_T",
    "4": "Plasma_cell_contaminant",
    "5": "Plasma_cell_contaminant",
    "6": "Plasma_cell_contaminant",
    "7": "Mast_DC_contaminant",
}
MYELOID_MAP = {
    "0": "Macrophage_LYVE1_FOLR2",
    "1": "Macrophage_LYVE1_resting",
    "2": "Cycling_myeloid",
    "3": "CD1C_DC",
    "4": "FCN1_Monocyte",
    "5": "Macrophage_SPP1_TREM2",
    "6": "Stromal_contaminant",
    "7": "CD1C_DC",
    "8": "CLEC9A_DC",
    "9": "Macrophage_MARCO_TIMD4",
    "10": "HLA_high_DC_like",
}
EVIDENCE = {
    "T_NK": {
        "0": "CD3D;TRAC;IL7R",
        "1": "NKG7;GNLY;KLRD1;PRF1 with low CD3D/TRAC",
        "2": "CD3D;CD8A;CD8B;CCL5;GZMK",
        "3": "CD3D;CD8A;CCL5;MKI67;TYMS",
        "4": "JCHAIN;IGHA1;CD79A;MZB1",
        "5": "immunoglobulins;CD79A;MZB1",
        "6": "immunoglobulins;SDC1;MZB1",
        "7": "FCER1A;CPA3;MS4A2;TPSAB1",
    },
    "Monocyte_DC": {
        "0": "C1QA;LYVE1;FOLR2;MRC1",
        "1": "C1QA;LYVE1;F13A1;MRC1",
        "2": "CCNA2;CDK1;UBE2C;TOP2A",
        "3": "CD1C;FCER1A;CLEC10A;HLA-DRA",
        "4": "FCN1;S100A8;S100A9;VCAN",
        "5": "SPP1;TREM2;FABP4;LPL",
        "6": "DCN;MGP;COL6A1;FBLN1",
        "7": "CD1C;FCER1A;CLEC10A;HLA-DRA",
        "8": "CLEC9A;WDFY4;DNASE1L3;HLA-DPA1",
        "9": "MARCO;TIMD4;C1QB;GPNMB",
        "10": "HLA-DRA;HLA-DPB1 with low LYZ/FCER1G",
    },
}


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--subcluster-dir", type=Path,
        default=root / "outputs/sc_revision/15_gse216651_published_qc_immune_subclusters",
    )
    parser.add_argument(
        "--outdir", type=Path,
        default=root / "outputs/sc_revision/16_gse216651_published_qc_immune_labels",
    )
    return parser.parse_args()


def context(label: str) -> str:
    if label in {"CD8_T", "Cycling_CD8_T"}:
        return "CD8_T"
    if label == "FCN1_Monocyte":
        return "FCN1_Monocyte"
    if "contaminant" in label:
        return "Excluded_contaminant"
    return "Other_immune"


def main() -> None:
    args = parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, object]] = []
    count_frames: list[pd.DataFrame] = []
    umap_frames: list[pd.DataFrame] = []
    for compartment, key, mapping in (
        ("T_NK", "T_NK_leiden", T_NK_MAP),
        ("Monocyte_DC", "Monocyte_DC_leiden", MYELOID_MAP),
    ):
        obj = ad.read_h5ad(args.subcluster_dir / f"{compartment}_subclustered.h5ad", backed="r")
        labels = obj.obs[key].astype(str).map(mapping)
        if labels.isna().any():
            raise ValueError(f"Unmapped {compartment} subclusters")
        frame = obj.obs[["gsm", "sample", "condition", key]].copy()
        frame["compartment"] = compartment
        frame["frozen_label"] = labels
        frame["analysis_context"] = labels.map(context)
        frame["UMAP1"] = obj.obsm["X_umap"][:, 0]
        frame["UMAP2"] = obj.obsm["X_umap"][:, 1]
        frame = frame.rename(columns={key: "subcluster"})
        umap_frames.append(frame)
        counts = (
            frame.groupby(
                ["compartment", "sample", "condition", "subcluster", "frozen_label", "analysis_context"],
                observed=True,
            ).size().rename("n_cells").reset_index()
        )
        count_frames.append(counts)
        for cluster, label in mapping.items():
            rows.append({
                "compartment": compartment,
                "subcluster": cluster,
                "frozen_label": label,
                "analysis_context": context(label),
                "marker_evidence": EVIDENCE[compartment][cluster],
                "annotation_method": "manual review of canonical and data-driven markers",
            })
        obj.file.close()

    mapping_frame = pd.DataFrame(rows)
    counts_frame = pd.concat(count_frames, ignore_index=True)
    mapping_frame.to_csv(args.outdir / "immune_subcluster_to_frozen_label.csv", index=False)
    counts_frame.to_csv(args.outdir / "immune_subtype_counts_by_donor.csv", index=False)
    pd.concat(umap_frames).to_csv(
        args.outdir / "immune_subtype_umap_metadata.csv.gz", index=False, compression="gzip"
    )
    context_counts = (
        counts_frame.groupby(["sample", "condition", "analysis_context"], observed=True)["n_cells"]
        .sum().reset_index()
    )
    context_counts.to_csv(args.outdir / "analysis_context_counts_by_donor.csv", index=False)
    parameters = {
        "scope": "strict-QC primary human transcriptomic analysis",
        "primary_context_definitions": {
            "CD8_T": "T/NK subclusters 2 and 3 (including cycling CD8-like T cells)",
            "FCN1_Monocyte": "monocyte/DC subcluster 4",
        },
        "annotation_boundary": "labels frozen before disease-group pseudobulk testing",
    }
    (args.outdir / "parameters.json").write_text(json.dumps(parameters, indent=2), encoding="utf-8")
    print(mapping_frame.to_string(index=False))
    print("\nPrimary context counts:\n", context_counts[context_counts.analysis_context.isin(["CD8_T", "FCN1_Monocyte"])].to_string(index=False))


if __name__ == "__main__":
    main()
