#!/usr/bin/env python3
"""Donor-level context-matched pseudobulk for the strict-QC primary analysis."""

from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
from scipy import sparse, stats


SAMPLES = ["sc_healthy_1", "sc_healthy_2", "sc_healthy_3", "sc_OA_1", "sc_OA_2", "sc_OA_3"]
CONDITION = {sample: ("healthy" if "healthy" in sample else "OA") for sample in SAMPLES}
GENES = ["APOBEC3G", "GTF2H1", "XRCC1", "BORCS7", "WBP1L", "H1F0", "GALT"]
DISPLAY = {gene: gene for gene in GENES} | {"BORCS7": "C10orf32/BORCS7"}
CONTEXT_GENES = {
    "Macrophage": ["APOBEC3G", "GTF2H1", "XRCC1"],
    "CD8_T": ["BORCS7", "WBP1L", "GALT"],
    "FCN1_Monocyte": ["H1F0"],
}
MR_BETA = {
    "APOBEC3G": 0.077, "GTF2H1": -0.088, "XRCC1": -0.106,
    "BORCS7": 0.185, "WBP1L": 0.207, "H1F0": 0.202, "GALT": 0.210,
}


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--atlas", type=Path,
        default=root / "outputs/sc_revision/13_gse216651_published_qc/objects/GSE216651_preliminary_processed.h5ad",
    )
    parser.add_argument(
        "--subcluster-dir", type=Path,
        default=root / "outputs/sc_revision/15_gse216651_published_qc_immune_subclusters",
    )
    parser.add_argument(
        "--tmj-results", type=Path,
        default=root / "outputs/sc_revision/05_gse205389_bulk/candidate_effects_and_tests.csv",
    )
    parser.add_argument(
        "--outdir", type=Path,
        default=root / "outputs/sc_revision/17_gse216651_published_qc_context_pseudobulk",
    )
    return parser.parse_args()


def bh_adjust(pvalues: np.ndarray) -> np.ndarray:
    values = np.asarray(pvalues, dtype=float)
    order = np.argsort(values)
    ranked = values[order]
    adjusted = ranked * len(values) / np.arange(1, len(values) + 1)
    adjusted = np.minimum.accumulate(adjusted[::-1])[::-1]
    result = np.empty_like(adjusted)
    result[order] = np.clip(adjusted, 0, 1)
    return result


def exact_p(values: np.ndarray) -> float:
    observed = abs(values[3:].mean() - values[:3].mean())
    permuted = []
    for oa in itertools.combinations(range(6), 3):
        healthy = [index for index in range(6) if index not in oa]
        permuted.append(abs(values[list(oa)].mean() - values[healthy].mean()))
    return float(np.mean(np.asarray(permuted) >= observed - 1e-12))


def welch_summary(oa: np.ndarray, healthy: np.ndarray) -> tuple[float, float, float, float]:
    effect = float(oa.mean() - healthy.mean())
    var_oa, var_h = float(oa.var(ddof=1)), float(healthy.var(ddof=1))
    se = float(np.sqrt(var_oa / 3 + var_h / 3))
    denominator = (var_oa / 3) ** 2 / 2 + (var_h / 3) ** 2 / 2
    dof = float((var_oa / 3 + var_h / 3) ** 2 / denominator) if denominator > 0 else 4.0
    if se == 0:
        return effect, effect, effect, 1.0
    critical = float(stats.t.ppf(0.975, dof))
    return effect, effect - critical * se, effect + critical * se, float(stats.ttest_ind(oa, healthy, equal_var=False).pvalue)


def direction(effect: float, beta: float) -> str:
    if not np.isfinite(effect) or effect == 0:
        return "indeterminate"
    return "concordant" if np.sign(effect) == np.sign(beta) else "discordant"


def main() -> None:
    args = parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    atlas = ad.read_h5ad(args.atlas)
    tnk = ad.read_h5ad(args.subcluster_dir / "T_NK_subclustered.h5ad", backed="r")
    myeloid = ad.read_h5ad(args.subcluster_dir / "Monocyte_DC_subclustered.h5ad", backed="r")
    selected = {
        "Macrophage": atlas.obs_names[atlas.obs["leiden_0_6"].astype(str).eq("2")],
        "CD8_T": tnk.obs_names[tnk.obs["T_NK_leiden"].astype(str).isin({"2", "3"})],
        "FCN1_Monocyte": myeloid.obs_names[myeloid.obs["Monocyte_DC_leiden"].astype(str).eq("4")],
    }
    tnk.file.close()
    myeloid.file.close()
    for name, indices in selected.items():
        if not indices.isin(atlas.obs_names).all():
            raise ValueError(f"{name} contains cells absent from the parent atlas")

    counts = atlas.layers["counts"]
    counts = sparse.csr_matrix(counts) if not sparse.issparse(counts) else counts.tocsr()
    gene_index = {gene: atlas.var_names.get_loc(gene) for gene in GENES}
    sample_rows: list[dict[str, object]] = []
    metadata_rows: list[dict[str, object]] = []

    for context, genes in CONTEXT_GENES.items():
        context_mask = atlas.obs_names.isin(selected[context])
        matrices: list[np.ndarray] = []
        for sample in SAMPLES:
            sample_mask = atlas.obs["sample"].astype(str).eq(sample).to_numpy()
            positions = np.flatnonzero(context_mask & sample_mask)
            summed = np.asarray(counts[positions].sum(axis=0)).ravel().astype(np.int64)
            matrices.append(summed)
            library_size = int(summed.sum())
            metadata_rows.append({
                "context": context, "sample": sample, "condition": CONDITION[sample],
                "n_cells": int(len(positions)), "library_size": library_size,
                "estimable_donor": bool(len(positions) > 0 and library_size > 0), "inference_unit": "donor",
            })
            for gene in genes:
                raw = int(summed[gene_index[gene]])
                log2_cpm = float(np.log2((raw + 0.5) / (library_size + 1.0) * 1_000_000)) if library_size > 0 else np.nan
                sample_rows.append({
                    "gene": DISPLAY[gene], "feature_symbol": gene, "prespecified_context": context,
                    "sample": sample, "condition": CONDITION[sample], "n_cells": int(len(positions)),
                    "library_size": library_size, "raw_pseudobulk_count": raw, "log2_cpm": log2_cpm,
                })
        pd.DataFrame(np.column_stack(matrices), index=atlas.var_names, columns=SAMPLES).to_csv(
            args.outdir / f"{context}_gene_by_donor_raw_counts.csv.gz", compression="gzip"
        )

    sample_frame = pd.DataFrame(sample_rows)
    metadata = pd.DataFrame(metadata_rows)
    sample_frame.to_csv(args.outdir / "candidate_context_matched_pseudobulk_by_donor.csv", index=False)
    metadata.to_csv(args.outdir / "pseudobulk_sample_metadata.csv", index=False)

    effect_rows: list[dict[str, object]] = []
    for feature in GENES:
        gene = DISPLAY[feature]
        group = sample_frame[sample_frame.gene.eq(gene)].set_index("sample").loc[SAMPLES]
        values = group["log2_cpm"].to_numpy(float)
        context = str(group["prespecified_context"].iloc[0])
        context_meta = metadata[metadata.context.eq(context)]
        estimable = bool(np.isfinite(values).all())
        if estimable:
            effect, low, high, welch_p = welch_summary(values[3:], values[:3])
            permutation_p = exact_p(values)
        else:
            effect = low = high = welch_p = permutation_p = np.nan
        min_cells = int(context_meta.n_cells.min())
        if not estimable:
            caution = "not estimable: at least one donor has zero cells in the prespecified context"
        elif min_cells < 10:
            caution = "very low context-cell counts (fewer than 10 cells in at least one donor)"
        else:
            caution = "none beyond n=3 donors per group"
        effect_rows.append({
            "gene": gene, "feature_symbol": feature, "prespecified_context": context,
            "healthy_mean_log2_cpm": float(np.nanmean(values[:3])) if np.isfinite(values[:3]).any() else np.nan,
            "oa_mean_log2_cpm": float(np.nanmean(values[3:])) if np.isfinite(values[3:]).any() else np.nan,
            "oa_minus_healthy_log2_cpm": effect, "effect_ci95_low": low, "effect_ci95_high": high,
            "exact_two_sided_permutation_p": permutation_p, "welch_t_p_secondary": welch_p,
            "n_healthy_donors_available": int(np.isfinite(values[:3]).sum()),
            "n_oa_donors_available": int(np.isfinite(values[3:]).sum()),
            "min_cells_per_donor": min_cells, "max_cells_per_donor": int(context_meta.n_cells.max()),
            "estimable_3_vs_3": estimable, "inference_unit": "donor", "mr_beta": MR_BETA[feature],
            "mr_direction": "higher risk" if MR_BETA[feature] > 0 else "lower risk",
            "sc_direction_vs_mr": direction(effect, MR_BETA[feature]), "interpretive_caution": caution,
        })

    effects = pd.DataFrame(effect_rows)
    exact_for_family = effects.exact_two_sided_permutation_p.fillna(1.0).to_numpy()
    welch_for_family = effects.welch_t_p_secondary.fillna(1.0).to_numpy()
    effects["exact_two_sided_permutation_p_bh_fdr"] = bh_adjust(exact_for_family)
    effects["welch_t_p_secondary_bh_fdr"] = bh_adjust(welch_for_family)
    effects.loc[~effects.estimable_3_vs_3, ["exact_two_sided_permutation_p_bh_fdr", "welch_t_p_secondary_bh_fdr"]] = np.nan
    effects.to_csv(args.outdir / "context_matched_donor_level_effects.csv", index=False)

    tmj = pd.read_csv(args.tmj_results)
    integrated = effects.merge(
        tmj[["gene", "tmjoa_minus_control_log2_expression", "exact_two_sided_permutation_p_bh_fdr"]]
        .rename(columns={"exact_two_sided_permutation_p_bh_fdr": "tmj_exact_bh_fdr"}),
        on="gene", how="left", validate="one_to_one",
    )
    integrated["tmj_direction_vs_mr"] = [
        direction(effect, beta) for effect, beta in zip(integrated.tmjoa_minus_control_log2_expression, integrated.mr_beta, strict=True)
    ]
    integrated.to_csv(args.outdir / "integrated_human_context_evidence.csv", index=False)

    parameters = {
        "dataset": "GSE216651",
        "scope": "strict-QC primary human transcriptomic analysis",
        "reference": "Raut et al., Communications Biology 2025, DOI 10.1038/s42003-025-08586-8",
        "prespecified_contexts": {
            "APOBEC3G;GTF2H1;XRCC1": "broad macrophage cluster 2",
            "BORCS7;WBP1L;GALT": "CD8-like T subclusters 2 and 3",
            "H1F0": "FCN1 monocyte subcluster 4",
        },
        "normalization": "raw UMI counts summed within donor/context; log2 CPM with 0.5-count prior only for non-empty pseudobulks",
        "statistical_boundary": "donors are biological replicates; cells are not independent replicates",
        "primary_test": "exact two-sided 3-vs-3 label permutation; minimum attainable P=0.1",
        "multiple_testing": "BH over the seven-gene family; non-estimable tests assigned P=1 for adjustment and reported as NA",
        "zero_cell_rule": "a zero-cell donor makes the corresponding 3-vs-3 gene comparison non-estimable",
    }
    (args.outdir / "parameters.json").write_text(json.dumps(parameters, indent=2), encoding="utf-8")
    print("Pseudobulk metadata:\n", metadata.to_string(index=False))
    print("\nEffects:\n", effects.to_string(index=False))


if __name__ == "__main__":
    main()
