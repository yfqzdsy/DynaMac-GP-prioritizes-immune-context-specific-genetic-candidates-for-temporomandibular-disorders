#!/usr/bin/env python3
"""Extract the seven prespecified genes from the public GSE205389 workbook.

The script reads the deposited mRNA FPKM workbook and GEO SOFT metadata and
writes the tidy input used by the tissue-level analysis. It performs no
statistical testing.
"""

from __future__ import annotations

import argparse
import gzip
from pathlib import Path

import openpyxl
import pandas as pd


CANDIDATES = {
    "APOBEC3G": "ENSG00000239713",
    "GTF2H1": "ENSG00000110768",
    "XRCC1": "ENSG00000073050",
    "C10orf32/BORCS7": "ENSG00000166275",
    "WBP1L": "ENSG00000166272",
    "H1F0": "ENSG00000189060",
    "GALT": "ENSG00000213930",
}


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--workbook",
        type=Path,
        default=root / "data/GSE205389/GSE205389_mRNA_Expression_Profiling.xlsx",
    )
    parser.add_argument(
        "--soft",
        type=Path,
        default=root / "data/GSE205389/GSE205389_family.soft.gz",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=root / "outputs/sc_revision/01_feasibility/GSE205389_candidate_expression.csv",
    )
    return parser.parse_args()


def parse_sample_metadata(path: Path) -> dict[str, dict[str, str]]:
    samples: dict[str, dict[str, str]] = {}
    current: dict[str, str] | None = None

    def commit(record: dict[str, str] | None) -> None:
        if record is None:
            return
        required = {"gsm", "sample", "title"}
        if not required.issubset(record):
            raise ValueError(f"Incomplete GSE205389 sample metadata: {record}")
        record["condition"] = (
            "TMJOA" if "TMJOA" in record["title"] else "disc_displacement_control"
        )
        samples[record["sample"]] = record

    with gzip.open(path, "rt") as handle:
        for raw_line in handle:
            line = raw_line.rstrip("\n")
            if line.startswith("^SAMPLE = "):
                commit(current)
                current = {"gsm": line.split(" = ", 1)[1]}
            elif current is not None and line.startswith("!Sample_title = "):
                current["title"] = line.split(" = ", 1)[1]
            elif current is not None and line.startswith("!Sample_description = "):
                value = line.split(" = ", 1)[1]
                if not value.lower().endswith(".xlsx") and "sample" not in current:
                    current["sample"] = value
    commit(current)
    if len(samples) != 10:
        raise ValueError(f"Expected 10 independent samples, found {len(samples)}")
    return samples


def main() -> None:
    args = parse_args()
    sample_metadata = parse_sample_metadata(args.soft)
    workbook = openpyxl.load_workbook(args.workbook, read_only=True, data_only=True)
    worksheet = workbook["mRNA Expression"]

    header: tuple[object, ...] | None = None
    selected: dict[str, tuple[object, ...]] = {}
    id_to_name = {ensembl: name for name, ensembl in CANDIDATES.items()}
    for row in worksheet.iter_rows(values_only=True):
        if row and row[0] == "gene_short_name":
            header = row
            continue
        if header is None or not row or row[1] is None:
            continue
        ensembl = str(row[1]).split(".", 1)[0]
        if ensembl in id_to_name:
            selected[id_to_name[ensembl]] = row
    workbook.close()

    if header is None:
        raise ValueError("The 'mRNA Expression' header row was not found")
    missing = sorted(set(CANDIDATES) - set(selected))
    if missing:
        raise ValueError(f"Candidate genes missing from the workbook: {missing}")

    header_index = {str(value): index for index, value in enumerate(header) if value is not None}
    rows: list[dict[str, object]] = []
    for priority_gene, ensembl in CANDIDATES.items():
        source = selected[priority_gene]
        for sample, metadata in sample_metadata.items():
            rows.append(
                {
                    "dataset": "GSE205389",
                    "priority_gene": priority_gene,
                    "feature_symbol": source[0],
                    "ensembl_id": ensembl,
                    "gsm": metadata["gsm"],
                    "sample": sample,
                    "condition": metadata["condition"],
                    "FPKM": source[header_index[f"{sample}_FPKM"]],
                    "count": source[header_index[f"{sample}_count"]],
                }
            )

    output = pd.DataFrame(rows)
    if output.shape[0] != 70:
        raise ValueError(f"Expected 70 gene-sample rows, found {output.shape[0]}")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    output.to_csv(args.output, index=False)
    print(f"Wrote {output.shape[0]} rows to {args.output}")


if __name__ == "__main__":
    main()
