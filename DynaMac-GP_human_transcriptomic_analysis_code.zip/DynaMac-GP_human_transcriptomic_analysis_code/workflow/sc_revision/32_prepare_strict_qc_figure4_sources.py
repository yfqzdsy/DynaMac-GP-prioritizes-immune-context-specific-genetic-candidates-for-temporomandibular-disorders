#!/usr/bin/env python3
"""Prepare non-visual Figure 4 source tables from the strict GSE216651 workflow.

The strict workflow follows the published secondary-analysis quality thresholds
(>=400 detected genes, >=3,000 UMIs and <=10% mitochondrial reads) and retains
32,153 donor-specific singlets.  This script joins the marker-frozen broad and
immune labels, excludes only explicitly identified immune contaminants from the
cell-context summaries, and calculates donor-first descriptive aggregates.  It
does not perform cell-level disease inference and it does not create figures.
"""

from __future__ import annotations

import argparse
import json
from itertools import combinations
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
from scipy import sparse


RANDOM_SEED = 20260809
GENES = ["APOBEC3G", "GTF2H1", "XRCC1", "BORCS7", "WBP1L", "H1F0", "GALT"]
SAMPLES = [
    "sc_healthy_1",
    "sc_healthy_2",
    "sc_healthy_3",
    "sc_OA_1",
    "sc_OA_2",
    "sc_OA_3",
]
CONDITIONS = {sample: ("healthy" if "healthy" in sample else "OA") for sample in SAMPLES}
CONTEXTS = [
    "Fibroblast",
    "Endothelial",
    "Perivascular",
    "Macrophage",
    "Other_Monocyte_DC",
    "FCN1_Monocyte",
    "Other_T_NK",
    "CD8_T",
]

BROAD_CLUSTER_MAP = {
    "0": "Fibroblast_PRG4",
    "1": "Fibroblast_COL14A1",
    "2": "Macrophage",
    "3": "Monocyte_DC",
    "4": "Fibroblast_CXCL14",
    "5": "Fibroblast_matrix",
    "6": "Pericyte_SMC",
    "7": "Endothelial",
    "8": "T_NK",
}
T_NK_MAP = {
    "0": "Other_T_NK",
    "1": "Other_T_NK",
    "2": "CD8_T",
    "3": "CD8_T",
    "4": "Excluded_contaminant",
    "5": "Excluded_contaminant",
    "6": "Excluded_contaminant",
    "7": "Excluded_contaminant",
}
MYELOID_MAP = {
    "0": "Other_Monocyte_DC",
    "1": "Other_Monocyte_DC",
    "2": "Other_Monocyte_DC",
    "3": "Other_Monocyte_DC",
    "4": "FCN1_Monocyte",
    "5": "Other_Monocyte_DC",
    "6": "Excluded_contaminant",
    "7": "Other_Monocyte_DC",
    "8": "Other_Monocyte_DC",
    "9": "Other_Monocyte_DC",
    "10": "Other_Monocyte_DC",
}


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--atlas",
        type=Path,
        default=root
        / "outputs/sc_revision/13_gse216651_published_qc/objects/GSE216651_preliminary_processed.h5ad",
    )
    parser.add_argument(
        "--subcluster-dir",
        type=Path,
        default=root / "outputs/sc_revision/15_gse216651_published_qc_immune_subclusters",
    )
    parser.add_argument(
        "--outdir",
        type=Path,
        default=root / "outputs/sc_revision/21_gse216651_strict_qc_figure4_sources",
    )
    return parser.parse_args()


def broad_context(label: str) -> str:
    if label.startswith("Fibroblast_"):
        return "Fibroblast"
    if label == "Pericyte_SMC":
        return "Perivascular"
    if label == "Monocyte_DC":
        return "Other_Monocyte_DC"
    if label == "T_NK":
        return "Other_T_NK"
    return label


def broad_display(label: str) -> str:
    if label.startswith("Fibroblast_"):
        return "Fibroblast"
    return {
        "Pericyte_SMC": "Perivascular",
        "Monocyte_DC": "Monocyte/DC",
        "T_NK": "T/NK",
    }.get(label, label)


def exact_two_sided_permutation_p(values: np.ndarray, conditions: np.ndarray) -> float:
    values = np.asarray(values, dtype=float)
    conditions = np.asarray(conditions)
    healthy = conditions == "healthy"
    if values.size != 6 or healthy.sum() != 3 or (~healthy).sum() != 3:
        return float("nan")
    observed = abs(values[~healthy].mean() - values[healthy].mean())
    all_effects: list[float] = []
    indices = np.arange(values.size)
    for healthy_indices in combinations(indices, 3):
        perm_healthy = np.zeros(values.size, dtype=bool)
        perm_healthy[list(healthy_indices)] = True
        all_effects.append(abs(values[~perm_healthy].mean() - values[perm_healthy].mean()))
    return float(np.mean(np.asarray(all_effects) >= observed - 1e-12))


def bh_adjust_with_na(values: pd.Series) -> np.ndarray:
    p = values.to_numpy(dtype=float)
    result = np.full(p.shape, np.nan, dtype=float)
    finite = np.isfinite(p)
    if not finite.any():
        return result
    finite_p = p[finite]
    order = np.argsort(finite_p)
    ranked = finite_p[order]
    adjusted_ranked = ranked * len(ranked) / np.arange(1, len(ranked) + 1)
    adjusted_ranked = np.minimum.accumulate(adjusted_ranked[::-1])[::-1]
    adjusted = np.empty_like(adjusted_ranked)
    adjusted[order] = np.minimum(adjusted_ranked, 1.0)
    result[finite] = adjusted
    return result


def main() -> None:
    args = parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    atlas = ad.read_h5ad(args.atlas)
    tnk = ad.read_h5ad(args.subcluster_dir / "T_NK_subclustered.h5ad", backed="r")
    myeloid = ad.read_h5ad(args.subcluster_dir / "Monocyte_DC_subclustered.h5ad", backed="r")

    observed_clusters = set(atlas.obs["leiden_0_6"].astype(str).unique())
    if observed_clusters != set(BROAD_CLUSTER_MAP):
        raise ValueError(f"Unexpected strict-QC broad clusters: {sorted(observed_clusters)}")
    if not set(tnk.obs_names).issubset(set(atlas.obs_names)):
        raise ValueError("T/NK subcluster cells are not a subset of the strict-QC atlas")
    if not set(myeloid.obs_names).issubset(set(atlas.obs_names)):
        raise ValueError("Monocyte/DC subcluster cells are not a subset of the strict-QC atlas")

    metadata = atlas.obs[["gsm", "sample", "condition", "leiden_0_6"]].copy()
    metadata["broad_cell_type"] = (
        metadata["leiden_0_6"].astype(str).map(BROAD_CLUSTER_MAP)
    )
    metadata["cell_class"] = metadata["broad_cell_type"].map(broad_display)
    metadata["analysis_context"] = metadata["broad_cell_type"].map(broad_context)
    metadata["primary_inference_eligible"] = True

    tnk_context = tnk.obs["T_NK_leiden"].astype(str).map(T_NK_MAP)
    myeloid_context = myeloid.obs["Monocyte_DC_leiden"].astype(str).map(MYELOID_MAP)
    if tnk_context.isna().any() or myeloid_context.isna().any():
        raise ValueError("An immune subcluster was not mapped to a strict-QC analysis context")
    metadata.loc[tnk_context.index, "analysis_context"] = tnk_context
    metadata.loc[myeloid_context.index, "analysis_context"] = myeloid_context
    metadata["primary_inference_eligible"] = ~metadata["analysis_context"].eq(
        "Excluded_contaminant"
    )
    metadata["UMAP1"] = atlas.obsm["X_umap"][:, 0]
    metadata["UMAP2"] = atlas.obsm["X_umap"][:, 1]

    if metadata.shape[0] != 32153:
        raise ValueError(f"Expected 32,153 strict-QC cells, found {metadata.shape[0]:,}")
    if set(metadata["sample"].astype(str)) != set(SAMPLES):
        raise ValueError("Strict-QC atlas does not contain the expected six donors")

    metadata.to_csv(
        args.outdir / "atlas_metadata_strict_qc.csv.gz", compression="gzip"
    )
    atlas_counts = (
        metadata.groupby(["sample", "condition", "cell_class"], observed=True)
        .size()
        .rename("n_cells")
        .reset_index()
    )
    atlas_counts.to_csv(args.outdir / "atlas_cell_counts_by_donor.csv", index=False)

    eligible = metadata.loc[
        metadata["primary_inference_eligible"]
        & metadata["analysis_context"].isin(CONTEXTS)
    ].copy()
    missing_genes = [gene for gene in GENES if gene not in atlas.var_names]
    if missing_genes:
        raise ValueError(f"Candidate genes absent from strict-QC atlas: {missing_genes}")

    matrix = atlas[eligible.index, GENES].X
    if sparse.issparse(matrix):
        matrix = matrix.toarray()
    matrix = np.asarray(matrix, dtype=np.float32)
    wide = pd.DataFrame(matrix, index=eligible.index, columns=GENES)
    wide.insert(0, "analysis_context", eligible["analysis_context"].to_numpy())
    wide.insert(0, "condition", eligible["condition"].to_numpy())
    wide.insert(0, "sample", eligible["sample"].to_numpy())
    wide.index.name = "cell_id"

    cell_long = wide.reset_index().melt(
        id_vars=["cell_id", "sample", "condition", "analysis_context"],
        value_vars=GENES,
        var_name="gene",
        value_name="log_normalized_expression",
    )
    cell_long.to_csv(
        args.outdir / "cell_level_seven_gene_expression.csv.gz",
        index=False,
        compression="gzip",
    )

    donor_expression = (
        cell_long.groupby(
            ["sample", "condition", "analysis_context", "gene"], observed=True
        )
        .agg(
            n_cells=("cell_id", "size"),
            mean_log_normalized_expression=("log_normalized_expression", "mean"),
            detected_fraction=(
                "log_normalized_expression",
                lambda x: float(np.mean(x > 0)),
            ),
        )
        .reset_index()
    )
    donor_expression.to_csv(
        args.outdir / "donor_context_gene_expression.csv", index=False
    )

    test_rows: list[dict[str, object]] = []
    for context in CONTEXTS:
        for gene in GENES:
            frame = donor_expression.loc[
                donor_expression["analysis_context"].eq(context)
                & donor_expression["gene"].eq(gene)
            ].copy()
            values = frame["mean_log_normalized_expression"].to_numpy(dtype=float)
            conditions = frame["condition"].to_numpy()
            healthy_values = values[conditions == "healthy"]
            oa_values = values[conditions == "OA"]
            test_rows.append(
                {
                    "analysis_context": context,
                    "gene": gene,
                    "n_healthy_donors": int(healthy_values.size),
                    "n_oa_donors": int(oa_values.size),
                    "healthy_mean_expression": float(healthy_values.mean())
                    if healthy_values.size
                    else np.nan,
                    "oa_mean_expression": float(oa_values.mean())
                    if oa_values.size
                    else np.nan,
                    "oa_minus_healthy": float(oa_values.mean() - healthy_values.mean())
                    if healthy_values.size and oa_values.size
                    else np.nan,
                    "exact_two_sided_permutation_p": exact_two_sided_permutation_p(
                        values, conditions
                    ),
                }
            )
    donor_tests = pd.DataFrame(test_rows)
    donor_tests["exact_permutation_bh_fdr_56_tests"] = bh_adjust_with_na(
        donor_tests["exact_two_sided_permutation_p"]
    )
    donor_tests.to_csv(args.outdir / "donor_level_condition_tests.csv", index=False)

    group_expression = (
        donor_expression.groupby(
            ["condition", "analysis_context", "gene"], observed=True
        )
        .agg(
            n_donors=("sample", "nunique"),
            mean_expression=("mean_log_normalized_expression", "mean"),
            sd_expression=("mean_log_normalized_expression", "std"),
            mean_detected_fraction=("detected_fraction", "mean"),
        )
        .reset_index()
    )
    group_expression["sem_expression"] = group_expression["sd_expression"] / np.sqrt(
        group_expression["n_donors"]
    )
    group_expression.to_csv(
        args.outdir / "condition_context_gene_summary.csv", index=False
    )

    overall_expression = (
        donor_expression.groupby(["analysis_context", "gene"], observed=True)
        .agg(
            n_donors=("sample", "nunique"),
            mean_expression=("mean_log_normalized_expression", "mean"),
            sd_expression=("mean_log_normalized_expression", "std"),
            mean_detected_fraction=("detected_fraction", "mean"),
        )
        .reset_index()
    )
    overall_expression["sem_expression"] = (
        overall_expression["sd_expression"]
        / np.sqrt(overall_expression["n_donors"])
    )
    overall_expression.to_csv(
        args.outdir / "overall_context_gene_summary.csv", index=False
    )

    observed_counts = (
        eligible.groupby(["sample", "condition", "analysis_context"], observed=True)
        .size()
        .rename("n_cells")
        .reset_index()
    )
    complete_counts = pd.MultiIndex.from_product(
        [SAMPLES, CONTEXTS], names=["sample", "analysis_context"]
    ).to_frame(index=False)
    complete_counts["condition"] = complete_counts["sample"].map(CONDITIONS)
    donor_counts = complete_counts.merge(
        observed_counts,
        on=["sample", "condition", "analysis_context"],
        how="left",
    )
    donor_counts["n_cells"] = donor_counts["n_cells"].fillna(0).astype(int)
    donor_totals = (
        eligible.groupby(["sample", "condition"], observed=True)
        .size()
        .rename("donor_total_eligible_cells")
        .reset_index()
    )
    donor_composition = donor_counts.merge(
        donor_totals, on=["sample", "condition"], how="left"
    )
    donor_composition["cell_fraction_within_donor"] = (
        donor_composition["n_cells"]
        / donor_composition["donor_total_eligible_cells"]
    )
    donor_composition.to_csv(
        args.outdir / "donor_context_cell_composition.csv", index=False
    )

    group_composition = (
        donor_composition.groupby(["condition", "analysis_context"], observed=True)
        .agg(
            n_donors=("sample", "nunique"),
            mean_donor_cell_fraction=("cell_fraction_within_donor", "mean"),
            sd_donor_cell_fraction=("cell_fraction_within_donor", "std"),
        )
        .reset_index()
    )
    group_composition["sem_donor_cell_fraction"] = (
        group_composition["sd_donor_cell_fraction"]
        / np.sqrt(group_composition["n_donors"])
    )
    denominators = group_composition.groupby("analysis_context")[
        "mean_donor_cell_fraction"
    ].transform("sum")
    group_composition["condition_share_within_context"] = (
        group_composition["mean_donor_cell_fraction"] / denominators
    )
    group_composition.to_csv(
        args.outdir / "condition_context_cell_composition_summary.csv", index=False
    )

    context_counts = (
        donor_counts.pivot(
            index=["sample", "condition"],
            columns="analysis_context",
            values="n_cells",
        )
        .reset_index()
    )
    context_counts.to_csv(args.outdir / "context_counts_by_donor_wide.csv", index=False)

    excluded_cells = int((~metadata["primary_inference_eligible"]).sum())
    manifest = {
        "dataset": "GSE216651",
        "workflow": "single strict-QC pipeline used for Figure 4 panels B-F",
        "quality_thresholds": {
            "minimum_detected_genes": 400,
            "minimum_umi_counts": 3000,
            "maximum_mitochondrial_fraction_percent": 10,
            "doublet_method": "Scrublet applied separately to each donor",
        },
        "input_singlets": int(metadata.shape[0]),
        "eligible_context_cells": int(eligible.shape[0]),
        "excluded_immune_contaminant_cells": excluded_cells,
        "biological_replicates": "three healthy donors and three OA donors",
        "genes": GENES,
        "analysis_contexts": CONTEXTS,
        "mast_context_boundary": (
            "No separate Mast context was retained because the strict-QC broad clustering "
            "did not support a stable mast-cell class; mast/DC-like immune contaminants "
            "were excluded rather than relabelled for display."
        ),
        "normalization": "library-size normalization to 10,000 counts followed by log1p",
        "aggregation": (
            "donor x analysis context first; available donor-context means are equally "
            "weighted; zero-cell donor-contexts are never imputed as zero expression"
        ),
        "composition": (
            "all donor x context combinations are retained; absent contexts contribute "
            "zero cells to donor-level cell fractions"
        ),
        "cell_level_use": "visualization/descriptive localization only; no cell-level disease test",
        "random_seed": RANDOM_SEED,
    }
    (args.outdir / "source_data_manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8"
    )

    tnk.file.close()
    myeloid.file.close()
    print(json.dumps(manifest, indent=2))
    print("\nStrict-QC cells by donor and context:")
    print(context_counts.to_string(index=False))


if __name__ == "__main__":
    main()
