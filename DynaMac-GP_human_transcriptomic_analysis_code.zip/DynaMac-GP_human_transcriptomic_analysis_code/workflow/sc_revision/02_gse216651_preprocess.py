#!/usr/bin/env python3
"""Sample-aware preliminary processing of six GSE216651 scRNA-seq donors.

Purpose
-------
This script establishes whether the three healthy and three OA donors contain
enough macrophage/myeloid cells for donor-level pseudobulk. It performs QC and
doublet removal per donor, integrates samples only for clustering/annotation,
and retains raw counts for subsequent pseudobulk. The provisional labels are
marker-panel assignments and must be checked against the original GSE216651
publication before manuscript use.

Statistical boundary
--------------------
No cell-level disease differential-expression test is performed here. Cells
are never treated as biological replicates.
"""

from __future__ import annotations

import argparse
import gzip
import importlib.metadata
import io
import json
import tarfile
import warnings
from pathlib import Path

import anndata as ad
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scanpy as sc
import scanpy.external as sce
import scipy.io
from scipy import sparse


RANDOM_SEED = 20260809

SAMPLES = (
    ("GSM6685302", "sc_healthy_1", "healthy"),
    ("GSM6685303", "sc_healthy_2", "healthy"),
    ("GSM6685304", "sc_healthy_3", "healthy"),
    ("GSM6685305", "sc_OA_1", "OA"),
    ("GSM6685306", "sc_OA_2", "OA"),
    ("GSM6685307", "sc_OA_3", "OA"),
)

CANDIDATES = ["APOBEC3G", "GTF2H1", "XRCC1", "BORCS7", "WBP1L", "H1F0", "GALT"]

BROAD_MARKERS = {
    "Fibroblast_stromal": ["COL1A1", "COL1A2", "COL3A1", "DCN", "LUM", "PDGFRA", "THY1", "PRG4"],
    "Endothelial": ["PECAM1", "VWF", "KDR", "EMCN", "CLDN5", "CDH5"],
    "Pericyte_SMC": ["RGS5", "PDGFRB", "CSPG4", "MCAM", "ACTA2", "MYH11", "TAGLN"],
    "Macrophage_myeloid": ["LST1", "TYROBP", "FCER1G", "CTSS", "CD68", "C1QA", "C1QB", "C1QC", "CSF1R"],
    "Neutrophil": ["S100A8", "S100A9", "FCGR3B", "CSF3R", "CXCR2"],
    "T_NK": ["CD3D", "CD3E", "TRAC", "NKG7", "KLRD1", "GNLY"],
    "B_plasma": ["MS4A1", "CD79A", "CD74", "CD37", "JCHAIN", "MZB1"],
    "Mast": ["TPSAB1", "TPSB2", "KIT", "CPA3"],
    "Schwann_neural": ["S100B", "SOX10", "PLP1", "MPZ"],
    "Proliferating": ["MKI67", "TOP2A", "PCLAF", "CENPF"],
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    root = Path(__file__).resolve().parents[2]
    parser.add_argument("--tar", type=Path, default=root / "data/GSE216651/GSE216651_RAW.tar")
    parser.add_argument("--outdir", type=Path, default=root / "outputs/sc_revision/02_gse216651")
    parser.add_argument("--min-genes", type=int, default=200)
    parser.add_argument("--max-genes", type=int, default=8000)
    parser.add_argument("--min-counts", type=int, default=500)
    parser.add_argument("--max-mt", type=float, default=20.0)
    parser.add_argument("--expected-doublet-rate", type=float, default=0.08)
    parser.add_argument("--n-hvg", type=int, default=2500)
    parser.add_argument("--n-pcs", type=int, default=30)
    parser.add_argument("--neighbors", type=int, default=15)
    parser.add_argument("--resolution", type=float, default=0.6)
    return parser.parse_args()


def open_gzip_text(tf: tarfile.TarFile, member: str) -> io.TextIOWrapper:
    raw = tf.extractfile(member)
    if raw is None:
        raise FileNotFoundError(member)
    return io.TextIOWrapper(gzip.GzipFile(fileobj=raw), encoding="utf-8")


def open_gzip_binary(tf: tarfile.TarFile, member: str) -> gzip.GzipFile:
    raw = tf.extractfile(member)
    if raw is None:
        raise FileNotFoundError(member)
    return gzip.GzipFile(fileobj=raw)


def read_sample(tf: tarfile.TarFile, gsm: str, sample: str, condition: str) -> ad.AnnData:
    prefix = f"{gsm}_{sample}"
    with open_gzip_text(tf, f"{prefix}_features.tsv.gz") as handle:
        features = [line.rstrip("\n").split("\t") for line in handle]
    gene_ids = [row[0] for row in features]
    gene_symbols = [row[1] if len(row) > 1 else row[0] for row in features]
    feature_types = [row[2] if len(row) > 2 else "Gene Expression" for row in features]
    with open_gzip_text(tf, f"{prefix}_barcodes.tsv.gz") as handle:
        barcodes = [line.strip() for line in handle]
    with open_gzip_binary(tf, f"{prefix}_matrix.mtx.gz") as handle:
        matrix = scipy.io.mmread(handle).tocsr().transpose().tocsr().astype(np.float32)
    if matrix.shape != (len(barcodes), len(gene_symbols)):
        raise ValueError(f"Matrix shape mismatch for {sample}: {matrix.shape}")
    result = ad.AnnData(X=matrix)
    result.obs_names = [f"{sample}:{barcode}" for barcode in barcodes]
    result.var_names = gene_symbols
    result.var["gene_id"] = gene_ids
    result.var["feature_type"] = feature_types
    result.var_names_make_unique()
    result.obs["gsm"] = gsm
    result.obs["sample"] = sample
    result.obs["condition"] = condition
    return result


def sparse_row_mean(matrix: sparse.spmatrix) -> np.ndarray:
    return np.asarray(matrix.mean(axis=0)).ravel()


def qc_and_doublets(adata: ad.AnnData, args: argparse.Namespace) -> tuple[ad.AnnData, dict[str, object]]:
    adata.var["mt"] = adata.var_names.str.upper().str.startswith("MT-")
    adata.var["ribo"] = adata.var_names.str.upper().str.startswith(("RPS", "RPL"))
    sc.pp.calculate_qc_metrics(adata, qc_vars=["mt", "ribo"], percent_top=None, log1p=False, inplace=True)
    before = adata.n_obs
    initial_qc = (
        (adata.obs["n_genes_by_counts"] >= args.min_genes)
        & (adata.obs["n_genes_by_counts"] <= args.max_genes)
        & (adata.obs["total_counts"] >= args.min_counts)
        & (adata.obs["pct_counts_mt"] <= args.max_mt)
    )
    adata = adata[initial_qc].copy()
    after_qc = adata.n_obs
    # Use Scanpy's supported wrapper, which performs the required internal
    # normalization/feature selection before Scrublet scoring. Passing the raw
    # matrix directly to the low-level Scrublet API produced degenerate,
    # constant scores with the current dependency versions.
    sc.pp.scrublet(
        adata,
        expected_doublet_rate=args.expected_doublet_rate,
        random_state=RANDOM_SEED,
    )
    predicted_doublets = adata.obs["predicted_doublet"].to_numpy(dtype=bool)
    n_doublets = int(predicted_doublets.sum())
    adata = adata[~adata.obs["predicted_doublet"]].copy()
    summary = {
        "sample": str(adata.obs["sample"].iloc[0]),
        "condition": str(adata.obs["condition"].iloc[0]),
        "input_barcodes": before,
        "after_qc": after_qc,
        "predicted_doublets": n_doublets,
        "retained_singlets": adata.n_obs,
        "retention_fraction": adata.n_obs / before,
        "median_counts_retained": float(adata.obs["total_counts"].median()),
        "median_genes_retained": float(adata.obs["n_genes_by_counts"].median()),
        "median_pct_mt_retained": float(adata.obs["pct_counts_mt"].median()),
        "scrublet_threshold": float(adata.uns["scrublet"]["threshold"]),
        "scrublet_threshold_method": "Scanpy/Scrublet automatic minimum between simulated-score modes",
    }
    return adata, summary


def save_qc_figure(qc_cells: pd.DataFrame, outdir: Path) -> None:
    metrics = [
        ("n_genes_by_counts", "Detected genes"),
        ("total_counts", "UMI counts"),
        ("pct_counts_mt", "Mitochondrial fraction (%)"),
        ("doublet_score", "Scrublet score"),
    ]
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    for axis, (metric, label) in zip(axes.ravel(), metrics, strict=True):
        for sample, group in qc_cells.groupby("sample", observed=True):
            values = group[metric].dropna().to_numpy()
            if values.size:
                axis.hist(values, bins=60, histtype="step", linewidth=1.2, label=sample, density=True)
        axis.set_xlabel(label)
        axis.set_ylabel("Density")
        axis.grid(False)
    axes[0, 0].legend(frameon=False, fontsize=8, ncol=2)
    fig.tight_layout()
    fig.savefig(outdir / "figures/QC_distributions.pdf")
    fig.savefig(outdir / "figures/QC_distributions.png", dpi=300)
    plt.close(fig)


def marker_panel_scores(adata: ad.AnnData, cluster_key: str) -> tuple[pd.DataFrame, dict[str, str]]:
    clusters = sorted(adata.obs[cluster_key].astype(str).unique(), key=lambda value: int(value))
    rows: list[dict[str, object]] = []
    for cluster in clusters:
        subset = adata[adata.obs[cluster_key].astype(str) == cluster]
        row: dict[str, object] = {"cluster": cluster, "n_cells": subset.n_obs}
        for label, markers in BROAD_MARKERS.items():
            present = [gene for gene in markers if gene in adata.var_names]
            row[f"{label}_markers_present"] = ";".join(present)
            row[f"{label}_mean_logexpr"] = float(sparse_row_mean(subset[:, present].X).mean()) if present else np.nan
            detected = np.asarray((subset[:, present].X > 0).mean(axis=0)).ravel() if present else np.array([])
            row[f"{label}_mean_detected_fraction"] = float(detected.mean()) if detected.size else np.nan
        rows.append(row)
    frame = pd.DataFrame(rows)
    score_columns = [f"{label}_mean_logexpr" for label in BROAD_MARKERS]
    standardized = frame[score_columns].copy()
    for column in score_columns:
        sd = standardized[column].std(ddof=0)
        standardized[column] = 0.0 if not np.isfinite(sd) or sd == 0 else (standardized[column] - standardized[column].mean()) / sd
    assignments: dict[str, str] = {}
    for index, row in standardized.iterrows():
        best_column = row.astype(float).idxmax()
        assignments[str(frame.loc[index, "cluster"])] = best_column.removesuffix("_mean_logexpr")
    frame["provisional_cell_type"] = frame["cluster"].map(assignments)
    return frame, assignments


def candidate_summary(adata: ad.AnnData) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for (sample, cell_type), index in adata.obs.groupby(["sample", "provisional_cell_type"], observed=True).groups.items():
        subset = adata[index]
        for gene in CANDIDATES:
            if gene not in adata.var_names:
                rows.append(
                    {
                        "sample": sample,
                        "condition": str(subset.obs["condition"].iloc[0]),
                        "provisional_cell_type": cell_type,
                        "gene": gene,
                        "n_cells": subset.n_obs,
                        "mean_log_normalized_expression": np.nan,
                        "detected_fraction": np.nan,
                    }
                )
                continue
            vector = subset[:, gene].X
            rows.append(
                {
                    "sample": sample,
                    "condition": str(subset.obs["condition"].iloc[0]),
                    "provisional_cell_type": cell_type,
                    "gene": gene,
                    "n_cells": subset.n_obs,
                    "mean_log_normalized_expression": float(vector.mean()),
                    "detected_fraction": float((vector > 0).mean()),
                }
            )
    return pd.DataFrame(rows)


def package_versions() -> dict[str, str]:
    names = ["scanpy", "anndata", "scrublet", "leidenalg", "igraph", "harmonypy", "numpy", "pandas", "scipy"]
    versions: dict[str, str] = {}
    for name in names:
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            versions[name] = "not_found"
    return versions


def main() -> None:
    args = parse_args()
    np.random.seed(RANDOM_SEED)
    sc.settings.n_jobs = min(8, 8)
    sc.settings.verbosity = 2
    args.outdir.mkdir(parents=True, exist_ok=True)
    for subdir in ("figures", "tables", "objects"):
        (args.outdir / subdir).mkdir(exist_ok=True)

    processed: list[ad.AnnData] = []
    qc_summaries: list[dict[str, object]] = []
    with tarfile.open(args.tar) as tf:
        for gsm, sample, condition in SAMPLES:
            print(f"Loading {sample}", flush=True)
            sample_data = read_sample(tf, gsm, sample, condition)
            sample_data, qc_summary = qc_and_doublets(sample_data, args)
            print(f"Retained {sample_data.n_obs:,} singlets for {sample}", flush=True)
            processed.append(sample_data)
            qc_summaries.append(qc_summary)

    adata = ad.concat(processed, join="inner", merge="same", index_unique=None)
    del processed
    adata.obs["sample"] = pd.Categorical(adata.obs["sample"], categories=[sample for _, sample, _ in SAMPLES])
    adata.obs["condition"] = pd.Categorical(adata.obs["condition"], categories=["healthy", "OA"])
    adata.layers["counts"] = adata.X.copy()

    qc_cells = adata.obs[
        ["gsm", "sample", "condition", "total_counts", "n_genes_by_counts", "pct_counts_mt", "pct_counts_ribo", "doublet_score"]
    ].copy()
    qc_cells.to_csv(args.outdir / "tables/cell_level_QC_retained.csv.gz", index=True, compression="gzip")
    pd.DataFrame(qc_summaries).to_csv(args.outdir / "tables/sample_QC_summary.csv", index=False)
    save_qc_figure(qc_cells, args.outdir)

    sc.pp.normalize_total(adata, target_sum=1e4)
    sc.pp.log1p(adata)
    adata.raw = adata
    sc.pp.highly_variable_genes(
        adata,
        n_top_genes=args.n_hvg,
        flavor="seurat",
        batch_key="sample",
        subset=False,
    )
    sc.pp.pca(adata, n_comps=args.n_pcs, use_highly_variable=True, random_state=RANDOM_SEED)
    sce.pp.harmony_integrate(adata, key="sample", basis="X_pca", adjusted_basis="X_pca_harmony", random_state=RANDOM_SEED)
    sc.pp.neighbors(
        adata,
        n_neighbors=args.neighbors,
        n_pcs=args.n_pcs,
        use_rep="X_pca_harmony",
        random_state=RANDOM_SEED,
    )
    sc.tl.umap(adata, random_state=RANDOM_SEED)
    cluster_key = "leiden_0_6"
    sc.tl.leiden(
        adata,
        resolution=args.resolution,
        key_added=cluster_key,
        random_state=RANDOM_SEED,
        flavor="igraph",
        n_iterations=2,
    )

    marker_scores, assignments = marker_panel_scores(adata, cluster_key)
    marker_scores.to_csv(args.outdir / "tables/provisional_cluster_marker_scores.csv", index=False)
    adata.obs["provisional_cell_type"] = adata.obs[cluster_key].astype(str).map(assignments).astype("category")

    cell_counts = (
        adata.obs.groupby(["sample", "condition", "provisional_cell_type"], observed=True)
        .size()
        .rename("n_cells")
        .reset_index()
    )
    cell_counts.to_csv(args.outdir / "tables/provisional_cell_counts_by_donor.csv", index=False)
    candidate_summary(adata).to_csv(args.outdir / "tables/candidate_expression_by_donor_celltype.csv", index=False)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        sc.tl.rank_genes_groups(
            adata,
            groupby=cluster_key,
            method="t-test_overestim_var",
            n_genes=100,
            use_raw=True,
            pts=True,
        )
    markers = sc.get.rank_genes_groups_df(adata, group=None)
    markers.to_csv(args.outdir / "tables/provisional_cluster_top_markers.csv.gz", index=False, compression="gzip")

    sc.pl.umap(adata, color=[cluster_key, "provisional_cell_type", "sample", "condition"], ncols=2, show=False)
    plt.gcf().set_size_inches(12, 10)
    plt.tight_layout()
    plt.savefig(args.outdir / "figures/preliminary_UMAP_overview.pdf", bbox_inches="tight")
    plt.savefig(args.outdir / "figures/preliminary_UMAP_overview.png", dpi=300, bbox_inches="tight")
    plt.close("all")

    present_candidates = [gene for gene in CANDIDATES if gene in adata.var_names]
    sc.pl.dotplot(
        adata,
        var_names=present_candidates,
        groupby="provisional_cell_type",
        use_raw=True,
        standard_scale="var",
        show=False,
    )
    plt.savefig(args.outdir / "figures/preliminary_candidate_dotplot.pdf", bbox_inches="tight")
    plt.savefig(args.outdir / "figures/preliminary_candidate_dotplot.png", dpi=300, bbox_inches="tight")
    plt.close("all")

    parameters = {
        "random_seed": RANDOM_SEED,
        "input_tar": args.tar.as_posix(),
        "samples": [{"gsm": gsm, "sample": sample, "condition": condition} for gsm, sample, condition in SAMPLES],
        "qc": {
            "min_genes": args.min_genes,
            "max_genes": args.max_genes,
            "min_counts": args.min_counts,
            "max_pct_mitochondrial": args.max_mt,
            "expected_doublet_rate": args.expected_doublet_rate,
            "doublet_method": "Scrublet applied separately to each donor",
        },
        "dimension_reduction": {
            "normalization": "library-size normalization to 10,000 counts followed by log1p",
            "n_hvg": args.n_hvg,
            "hvg_flavor": "seurat with sample batch key",
            "n_pcs": args.n_pcs,
            "integration": "Harmony on PCA for visualization/clustering only",
            "neighbors": args.neighbors,
            "leiden_resolution": args.resolution,
        },
        "annotation_status": "provisional marker-panel assignment; requires original-publication/manual review",
        "differential_expression_boundary": "No cell-level healthy-vs-OA test performed",
        "package_versions": package_versions(),
    }
    (args.outdir / "parameters.json").write_text(json.dumps(parameters, indent=2), encoding="utf-8")
    adata.write_h5ad(args.outdir / "objects/GSE216651_preliminary_processed.h5ad", compression="gzip")

    macrophage_counts = cell_counts[cell_counts["provisional_cell_type"] == "Macrophage_myeloid"].copy()
    print("\nProvisional macrophage/myeloid counts by donor:")
    print(macrophage_counts.to_string(index=False))


if __name__ == "__main__":
    main()
