#!/usr/bin/env python3
"""Run the complete strict-QC GSE216651 single-cell analysis."""

from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
WORKFLOW = ROOT / "workflow/sc_revision"


def run(script: str, *arguments: str) -> None:
    subprocess.run(
        [sys.executable, str(WORKFLOW / script), *arguments],
        cwd=ROOT,
        check=True,
    )


if __name__ == "__main__":
    run(
        "02_gse216651_preprocess.py",
        "--outdir", "outputs/sc_revision/13_gse216651_published_qc",
        "--min-genes", "400",
        "--max-genes", "100000",
        "--min-counts", "3000",
        "--max-mt", "10",
        "--n-hvg", "2000",
        "--n-pcs", "20",
        "--neighbors", "15",
        "--resolution", "0.5",
    )
    run("16_gse216651_published_qc_freeze_annotations.py")
    run("17_gse216651_published_qc_immune_subclusters.py")
    run("18_gse216651_published_qc_freeze_immune_labels.py")
    run("19_gse216651_published_qc_context_pseudobulk.py")
    run("32_prepare_strict_qc_figure4_sources.py")
