#!/usr/bin/env python3
"""Run the complete GSE205389 bulk RNA-seq analysis."""

from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
WORKFLOW = ROOT / "workflow/sc_revision"


def run(script: str) -> None:
    subprocess.run([sys.executable, str(WORKFLOW / script)], cwd=ROOT, check=True)


if __name__ == "__main__":
    run("01_extract_gse205389.py")
    run("05_gse205389_tmj_bulk.py")
