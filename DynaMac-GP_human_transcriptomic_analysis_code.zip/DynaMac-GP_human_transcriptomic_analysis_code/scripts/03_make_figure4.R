#!/usr/bin/env Rscript

# Figure 4 generated from one strict GSE216651 workflow for panels B-F.
# Panel A retains the independent human TMJ bulk dataset.  Cells are used only
# for visualization/localization; donors or independent tissue samples are the
# biological replicate units for inferential panels.

suppressPackageStartupMessages({
  library(ggplot2)
  library(patchwork)
  library(scales)
})

root <- normalizePath(getwd())
source_dir <- file.path(
  root, "outputs/sc_revision/21_gse216651_strict_qc_figure4_sources"
)
outdir <- file.path(root, "outputs/sc_revision/Figure4_strict_qc_unified")
dir.create(outdir, recursive = TRUE, showWarnings = FALSE)

gene_order <- c(
  "APOBEC3G", "GTF2H1", "XRCC1", "C10orf32/BORCS7",
  "WBP1L", "H1F0", "GALT"
)
source_gene_order <- c(
  "APOBEC3G", "GTF2H1", "XRCC1", "BORCS7", "WBP1L", "H1F0", "GALT"
)
gene_axis_labels <- c(
  "APOBEC3G" = "APOBEC3G", "GTF2H1" = "GTF2H1", "XRCC1" = "XRCC1",
  "C10orf32/BORCS7" = "C10orf32/\nBORCS7", "WBP1L" = "WBP1L",
  "H1F0" = "H1F0", "GALT" = "GALT"
)
gene_display <- c(
  "APOBEC3G" = "APOBEC3G", "GTF2H1" = "GTF2H1", "XRCC1" = "XRCC1",
  "BORCS7" = "C10orf32/BORCS7", "WBP1L" = "WBP1L",
  "H1F0" = "H1F0", "GALT" = "GALT"
)
gene_colors <- c(
  APOBEC3G = "#2F7196", GTF2H1 = "#458D80", XRCC1 = "#78A05B",
  BORCS7 = "#D2A03A", WBP1L = "#D77945", H1F0 = "#B65370",
  GALT = "#76579A"
)
condition_colors <- c(healthy = "#4C78A8", OA = "#D7655B")

context_order <- c(
  "Fibroblast", "Endothelial", "Perivascular", "Macrophage",
  "Other_Monocyte_DC", "FCN1_Monocyte", "Other_T_NK", "CD8_T"
)
context_labels <- c(
  "Fibroblast", "Endothelial", "Perivascular", "Macrophage",
  "Other\nmonocyte/DC", "FCN1\nmonocyte", "Other T/NK", "CD8 T"
)

theme_base <- theme_classic(base_size = 6.5, base_family = "Helvetica") +
  theme(
    axis.line = element_line(linewidth = 0.28, colour = "#333333"),
    axis.ticks = element_line(linewidth = 0.28, colour = "#333333"),
    axis.text = element_text(size = 5.0, colour = "#222222"),
    axis.title = element_text(size = 5.8, colour = "#222222"),
    legend.title = element_text(size = 5.2),
    legend.text = element_text(size = 5.0),
    legend.key.height = unit(5, "pt"),
    legend.key.width = unit(7, "pt"),
    panel.grid = element_blank(),
    plot.margin = margin(2, 3, 2, 4, unit = "pt")
  )

# A: independent human TMJ synovium bulk RNA-seq (5 controls and 5 TMJOA).
bulk <- read.csv(
  file.path(
    root,
    "outputs/sc_revision/05_gse205389_bulk/candidate_sample_expression.csv"
  ),
  check.names = FALSE
)
bulk$gene <- factor(bulk$priority_gene, levels = gene_order)
bulk$group <- factor(
  bulk$condition,
  levels = c("disc_displacement_control", "TMJOA"),
  labels = c("DD control", "TMJOA")
)
bulk_tests <- read.csv(
  file.path(
    root,
    "outputs/sc_revision/05_gse205389_bulk/candidate_effects_and_tests.csv"
  ),
  check.names = FALSE
)
bulk_tests$gene <- factor(bulk_tests$gene, levels = gene_order)
bulk_tests$q_label <- paste0(
  "q=", sub(
    "^0", "",
    formatC(
      bulk_tests$exact_two_sided_permutation_p_bh_fdr,
      format = "f", digits = 3
    )
  )
)
bulk_label_y <- max(bulk$log2_fpkm_plus_1, na.rm = TRUE) + 0.42
bulk_tests$label_y <- bulk_label_y

p_a <- ggplot(
  bulk,
  aes(
    gene, log2_fpkm_plus_1, colour = group, fill = group,
    group = interaction(gene, group)
  )
) +
  geom_boxplot(
    width = 0.52, linewidth = 0.32, alpha = 0.10, outlier.shape = NA,
    position = position_dodge(width = 0.62)
  ) +
  geom_point(
    size = 1.15, alpha = 0.95, stroke = 0.25, shape = 21,
    position = position_jitterdodge(
      jitter.width = 0.09, jitter.height = 0, dodge.width = 0.62,
      seed = 20260810
    )
  ) +
  geom_text(
    data = bulk_tests,
    aes(gene, label_y, label = q_label), inherit.aes = FALSE,
    size = 1.78, colour = "#353535"
  ) +
  scale_colour_manual(
    values = c("DD control" = condition_colors[["healthy"]],
               "TMJOA" = condition_colors[["OA"]]),
    name = NULL
  ) +
  scale_fill_manual(
    values = c("DD control" = condition_colors[["healthy"]],
               "TMJOA" = condition_colors[["OA"]]),
    name = NULL
  ) +
  scale_x_discrete(labels = gene_axis_labels, expand = expansion(add = 0.48)) +
  scale_y_continuous(
    limits = c(0, bulk_label_y + 0.18), expand = expansion(mult = c(0, 0.01))
  ) +
  labs(title = NULL, subtitle = NULL, x = NULL, y = "log2(FPKM + 1)") +
  theme_base +
  theme(
    axis.text.x = element_text(size = 5.0, lineheight = 0.88),
    legend.position = "bottom", legend.justification = "center",
    legend.box.just = "center", legend.margin = margin(0, 0, 0, 0)
  ) +
  guides(
    colour = guide_legend(
      nrow = 1, byrow = TRUE,
      override.aes = list(shape = 16, size = 1.6, alpha = 1)
    ),
    fill = "none"
  )

# B: all 32,153 strict-QC singlets; cells are visualization units only.
atlas <- read.csv(
  gzfile(file.path(source_dir, "atlas_metadata_strict_qc.csv.gz")),
  check.names = FALSE
)
broad_order <- c(
  "Fibroblast", "Endothelial", "Perivascular", "Macrophage",
  "Monocyte/DC", "T/NK"
)
broad_palette <- c(
  "Fibroblast" = "#B56C14", "Endothelial" = "#216A8A",
  "Perivascular" = "#5B3D7A", "Macrophage" = "#963341",
  "Monocyte/DC" = "#BD4F22", "T/NK" = "#2E477D"
)
atlas$cell_class <- factor(atlas$cell_class, levels = broad_order)

p_b <- ggplot(atlas, aes(UMAP2, -UMAP1, colour = cell_class)) +
  geom_point(size = 0.14, alpha = 0.95, stroke = 0) +
  scale_colour_manual(values = broad_palette, drop = FALSE, name = NULL) +
  coord_equal(expand = FALSE) +
  labs(title = NULL, subtitle = NULL, x = NULL, y = NULL) +
  theme_void(base_size = 6.5, base_family = "Helvetica") +
  theme(
    legend.text = element_text(size = 5.0),
    legend.key.height = unit(5.0, "pt"),
    legend.position = "right", legend.margin = margin(0, 0, 0, 0),
    legend.box.spacing = unit(1, "pt"),
    plot.margin = margin(0, 0, 0, 0, unit = "pt")
  ) +
  guides(colour = guide_legend(
    ncol = 1, byrow = TRUE,
    override.aes = list(size = 1.5, alpha = 1)
  ))

# C: donor-first descriptive localization and donor-level condition shares.
overall <- read.csv(
  file.path(source_dir, "overall_context_gene_summary.csv"),
  check.names = FALSE
)
composition <- read.csv(
  file.path(source_dir, "condition_context_cell_composition_summary.csv"),
  check.names = FALSE
)
overall$gene <- factor(overall$gene, levels = source_gene_order)
overall$analysis_context <- factor(overall$analysis_context, levels = context_order)
composition$condition <- factor(composition$condition, levels = c("healthy", "OA"))
composition$analysis_context <- factor(
  composition$analysis_context, levels = context_order
)
gene_offsets <- setNames(seq(-0.30, 0.30, length.out = 7), source_gene_order)
overall$context_index <- match(as.character(overall$analysis_context), context_order)
overall$x_position <- overall$context_index +
  unname(gene_offsets[as.character(overall$gene)])
composition$context_index <- match(
  as.character(composition$analysis_context), context_order
)
expression_limit <- max(
  0.5, ceiling(max(overall$mean_expression, na.rm = TRUE) * 4.1) / 4
)
expression_breaks <- pretty(c(0, expression_limit), n = 4)
expression_breaks <- expression_breaks[
  expression_breaks >= 0 & expression_breaks <= expression_limit
]

p_c_lollipop <- ggplot(overall, aes(x_position, mean_expression, colour = gene)) +
  geom_hline(
    yintercept = expression_breaks[expression_breaks > 0],
    colour = "#E2E3E5", linewidth = 0.24, linetype = "dashed"
  ) +
  geom_segment(
    aes(xend = x_position, y = 0, yend = mean_expression),
    colour = "#C4C6C8", linewidth = 0.42
  ) +
  geom_point(size = 1.40) +
  scale_colour_manual(
    values = gene_colors, breaks = source_gene_order,
    labels = gene_display, name = "Gene"
  ) +
  scale_x_continuous(
    limits = c(0.55, 8.45), breaks = seq_len(8), labels = rep("", 8),
    expand = c(0, 0)
  ) +
  scale_y_continuous(
    limits = c(0, expression_limit), breaks = expression_breaks,
    expand = expansion(mult = c(0, 0.03))
  ) +
  labs(title = NULL, subtitle = NULL, x = NULL, y = "Mean expression") +
  theme_base +
  theme(
    axis.text.x = element_blank(), axis.ticks.x = element_blank(),
    axis.line.x = element_blank(), legend.position = "bottom"
  ) +
  guides(colour = guide_legend(ncol = 4, byrow = TRUE))

p_c_composition <- ggplot(
  composition,
  aes(context_index, condition_share_within_context, fill = condition)
) +
  geom_col(width = 0.72, colour = "white", linewidth = 0.20) +
  scale_fill_manual(
    values = condition_colors, breaks = c("healthy", "OA"),
    labels = c("Healthy", "OA"), name = "Condition"
  ) +
  scale_x_continuous(
    limits = c(0.55, 8.45), breaks = seq_len(8), labels = context_labels,
    expand = c(0, 0)
  ) +
  scale_y_continuous(
    limits = c(0, 1), breaks = c(0, 0.5, 1),
    labels = c("0%", "50%", "100%"), expand = c(0, 0)
  ) +
  labs(title = NULL, subtitle = NULL, x = NULL, y = "Condition share") +
  theme_base +
  theme(
    axis.text.x = element_text(angle = 43, hjust = 1, vjust = 1, size = 5.0),
    legend.position = "bottom"
  ) +
  guides(fill = guide_legend(nrow = 1, byrow = TRUE))

p_c_nested <- p_c_lollipop / p_c_composition +
  plot_layout(heights = c(0.94, 1.06), guides = "keep")
p_c <- wrap_elements(full = p_c_nested) + theme(plot.tag.position = c(0, 1))

# D: donor-equal localization heatmap from the same strict-QC source.
heat <- overall[, c("gene", "analysis_context", "mean_expression", "n_donors")]
heat$gene_chr <- as.character(heat$gene)
heat$context_chr <- as.character(heat$analysis_context)
heat$row_z_score <- 0
for (gene_name in source_gene_order) {
  idx <- which(heat$gene_chr == gene_name)
  values <- heat$mean_expression[idx]
  heat$row_z_score[idx] <- if (length(unique(values)) > 1) {
    as.numeric(scale(values))
  } else {
    0
  }
}
heat$gene_display <- gene_display[heat$gene_chr]
heat$gene_display <- factor(heat$gene_display, levels = rev(gene_order))
heat$analysis_context <- factor(heat$context_chr, levels = context_order)

p_d <- ggplot(heat, aes(analysis_context, gene_display, fill = row_z_score)) +
  geom_tile(colour = "white", linewidth = 0.45) +
  scale_x_discrete(labels = context_labels, expand = c(0, 0)) +
  scale_y_discrete(expand = c(0, 0)) +
  scale_fill_gradient2(
    low = "#376F9B", mid = "#F4F2EE", high = "#B64F59",
    midpoint = 0, limits = c(-2, 2), oob = squish,
    name = "Within-gene\nz-score"
  ) +
  labs(title = NULL, subtitle = NULL, x = NULL, y = NULL) +
  theme_base +
  theme(
    axis.line = element_blank(), axis.ticks = element_blank(),
    axis.text.x = element_text(angle = 42, hjust = 1, size = 5.0,
                               lineheight = 0.88),
    axis.text.y = element_text(size = 5.1),
    panel.border = element_rect(fill = NA, colour = "#8A8A8A", linewidth = 0.25),
    legend.position = "right"
  )

# E: strict-QC donor-level pseudobulk in prespecified cell contexts.
donor <- read.csv(
  file.path(
    root,
    paste0(
      "outputs/sc_revision/17_gse216651_published_qc_context_pseudobulk/",
      "candidate_context_matched_pseudobulk_by_donor.csv"
    )
  ),
  check.names = FALSE
)
donor$condition_display <- factor(
  donor$condition, levels = c("healthy", "OA"), labels = c("Healthy", "OA")
)
donor$gene <- factor(donor$gene, levels = gene_order)
donor$display_z <- ave(
  donor$log2_cpm, donor$gene,
  FUN = function(x) {
    spread <- sd(x, na.rm = TRUE)
    if (is.finite(spread) && spread > 0) {
      (x - mean(x, na.rm = TRUE)) / spread
    } else {
      rep(0, length(x))
    }
  }
)
donor_plot <- donor[is.finite(donor$display_z), ]
donor_effect <- read.csv(
  file.path(
    root,
    paste0(
      "outputs/sc_revision/17_gse216651_published_qc_context_pseudobulk/",
      "context_matched_donor_level_effects.csv"
    )
  ),
  check.names = FALSE
)
donor_effect$gene <- factor(donor_effect$gene, levels = gene_order)
donor_effect$p_label <- ifelse(
  is.na(donor_effect$exact_two_sided_permutation_p), "NE",
  paste0(
    "P=", formatC(
      donor_effect$exact_two_sided_permutation_p, format = "f", digits = 1
    )
  )
)
donor_label_y <- max(donor$display_z, na.rm = TRUE) + 0.36
donor_effect$label_y <- donor_label_y
context_short <- c(
  "APOBEC3G" = "APOBEC3G\nMacro.", "GTF2H1" = "GTF2H1\nMacro.",
  "XRCC1" = "XRCC1\nMacro.",
  "C10orf32/BORCS7" = "C10orf32/\nBORCS7\nCD8 T",
  "WBP1L" = "WBP1L\nCD8 T", "H1F0" = "H1F0\nFCN1 mono.",
  "GALT" = "GALT\nCD8 T"
)

p_e <- ggplot(
  donor_plot,
  aes(gene, display_z, colour = condition_display, group = condition_display)
) +
  geom_hline(yintercept = 0, colour = "#D5D7D9", linewidth = 0.25) +
  stat_summary(
    fun = mean, geom = "crossbar", width = 0.30, linewidth = 0.48,
    position = position_dodge(width = 0.54)
  ) +
  geom_point(
    size = 1.25, alpha = 0.95,
    position = position_jitterdodge(
      jitter.width = 0.08, jitter.height = 0, dodge.width = 0.54,
      seed = 20260810
    )
  ) +
  geom_text(
    data = donor_effect,
    aes(gene, label_y, label = p_label), inherit.aes = FALSE,
    size = 1.78, colour = "#353535"
  ) +
  scale_colour_manual(
    values = c("Healthy" = condition_colors[["healthy"]],
               "OA" = condition_colors[["OA"]]),
    name = NULL
  ) +
  scale_x_discrete(labels = context_short, expand = expansion(add = 0.45)) +
  scale_y_continuous(
    limits = c(min(donor$display_z, na.rm = TRUE) - 0.18,
               donor_label_y + 0.18),
    expand = expansion(mult = c(0, 0.01))
  ) +
  labs(
    title = NULL, subtitle = NULL, x = NULL,
    y = "Within-gene standardized log2 CPM"
  ) +
  theme_base +
  theme(
    axis.text.x = element_text(size = 5.0, lineheight = 0.86),
    legend.position = "bottom", legend.justification = "center",
    legend.box.just = "center", legend.margin = margin(0, 0, 0, 0)
  ) +
  guides(colour = guide_legend(
    nrow = 1, byrow = TRUE,
    override.aes = list(size = 1.7)
  ))

# F: direction/evidence synthesis using the same strict-QC pseudobulk source.
integrated <- read.csv(
  file.path(
    root,
    paste0(
      "outputs/sc_revision/17_gse216651_published_qc_context_pseudobulk/",
      "integrated_human_context_evidence.csv"
    )
  ),
  check.names = FALSE
)

format_effect <- function(x, digits) {
  ifelse(is.finite(x), sprintf(paste0("%+.", digits, "f"), x), "NE")
}

mr_rows <- data.frame(
  gene = integrated$gene, evidence = "MR", effect = integrated$mr_beta,
  p_value = NA_real_, status = "MR estimate", significant = FALSE,
  stringsAsFactors = FALSE
)
sc_rows <- data.frame(
  gene = integrated$gene, evidence = "Matched scRNA",
  effect = integrated$oa_minus_healthy_log2_cpm,
  p_value = integrated$exact_two_sided_permutation_p,
  status = integrated$sc_direction_vs_mr,
  significant = !is.na(integrated$exact_two_sided_permutation_p_bh_fdr) &
    integrated$exact_two_sided_permutation_p_bh_fdr < 0.05,
  stringsAsFactors = FALSE
)
tmj_rows <- data.frame(
  gene = integrated$gene, evidence = "TMJ bulk",
  effect = integrated$tmjoa_minus_control_log2_expression,
  p_value = integrated$tmj_exact_bh_fdr,
  status = integrated$tmj_direction_vs_mr,
  significant = !is.na(integrated$tmj_exact_bh_fdr) &
    integrated$tmj_exact_bh_fdr < 0.05,
  stringsAsFactors = FALSE
)
evidence <- rbind(mr_rows, sc_rows, tmj_rows)
evidence$status[is.na(evidence$status)] <- "indeterminate"
evidence$status[!is.finite(evidence$effect)] <- "indeterminate"
evidence$outline <- ifelse(
  evidence$significant, "FDR < 0.05", "Not FDR-significant"
)
evidence$strength <- ifelse(
  evidence$evidence == "MR", 1.0,
  ifelse(
    is.finite(evidence$p_value),
    pmin(-log10(pmax(evidence$p_value, .Machine$double.xmin)), 2),
    0.20
  )
)
evidence$label <- ifelse(
  evidence$evidence == "MR",
  format_effect(evidence$effect, 3),
  format_effect(evidence$effect, 2)
)
evidence$label <- paste0(
  evidence$label, ifelse(evidence$significant, "*", "")
)
evidence$label_colour <- ifelse(
  evidence$status == "indeterminate", "dark", "light"
)
evidence$gene <- factor(evidence$gene, levels = rev(gene_order))
evidence$evidence <- factor(
  evidence$evidence, levels = c("MR", "Matched scRNA", "TMJ bulk")
)
status_palette <- c(
  "MR estimate" = "#687487", "concordant" = "#4C78A8",
  "discordant" = "#D7655B", "indeterminate" = "#C8CDD2"
)
outline_palette <- c(
  "FDR < 0.05" = "#222222", "Not FDR-significant" = "white"
)

p_f <- ggplot(evidence, aes(evidence, gene)) +
  geom_tile(fill = "#F5F7FA", colour = "white", linewidth = 0.55) +
  geom_point(
    aes(size = strength, fill = status, colour = outline),
    shape = 21, stroke = 0.55
  ) +
  geom_text(
    data = evidence[evidence$label_colour == "light", ],
    aes(label = label), colour = "white", size = 1.80, fontface = "bold"
  ) +
  geom_text(
    data = evidence[evidence$label_colour == "dark", ],
    aes(label = label), colour = "#333333", size = 1.80, fontface = "bold"
  ) +
  scale_size_continuous(range = c(5.2, 8.8), limits = c(0, 2), guide = "none") +
  scale_fill_manual(
    values = status_palette,
    breaks = c("MR estimate", "concordant", "discordant", "indeterminate"),
    labels = c("MR estimate", "Concordant", "Discordant", "Not estimable"),
    name = NULL
  ) +
  scale_colour_manual(values = outline_palette, guide = "none") +
  scale_x_discrete(expand = c(0, 0)) +
  scale_y_discrete(expand = c(0, 0)) +
  labs(title = NULL, subtitle = NULL, x = NULL, y = NULL) +
  theme_base +
  theme(
    axis.line = element_blank(), axis.ticks = element_blank(),
    axis.text.x = element_text(size = 5.2, face = "bold", colour = "#222222"),
    axis.text.y = element_text(size = 5.1, colour = "#222222"),
    legend.position = "right", legend.justification = "center",
    legend.box.just = "center",
    panel.border = element_rect(fill = NA, colour = "#8A8A8A", linewidth = 0.25),
    plot.margin = margin(3, 3, 3, 3, unit = "pt")
  ) +
  guides(fill = guide_legend(
    ncol = 1, byrow = TRUE, override.aes = list(size = 3.2)
  ))

# Two aligned columns; A/C/E and B/D/F share fixed column guides.
layout_design <- "
A#B
C#D
E#F
"
main_figure <- p_a + p_b + p_c + p_d + p_e + p_f +
  plot_layout(
    design = layout_design,
    widths = c(1, 0.055, 1), heights = c(1, 1, 0.92), guides = "keep"
  ) +
  plot_annotation(tag_levels = "A") &
  theme(
    plot.tag = element_text(size = 10.5, family = "Times", face = "bold"),
    plot.tag.position = c(0, 1)
  )

save_figure <- function(plot, stem, width_mm = 190, height_mm = 220, dpi = 600) {
  width_in <- width_mm / 25.4
  height_in <- height_mm / 25.4
  pdf_path <- file.path(outdir, paste0(stem, ".pdf"))
  cairo_runtime_ok <- isTRUE(capabilities("cairo")) &&
    !(identical(Sys.info()[["sysname"]], "Darwin") &&
      !file.exists("/opt/X11/lib/libXrender.1.dylib"))
  if (cairo_runtime_ok) {
    grDevices::cairo_pdf(
      pdf_path, width = width_in, height = height_in, family = "Helvetica"
    )
  } else {
    grDevices::pdf(
      pdf_path, width = width_in, height = height_in,
      family = "Helvetica", useDingbats = FALSE
    )
  }
  print(plot)
  dev.off()

  svglite::svglite(
    file.path(outdir, paste0(stem, ".svg")),
    width = width_in, height = height_in,
    system_fonts = list(Helvetica = "Helvetica", Times = "Times New Roman")
  )
  print(plot)
  dev.off()

  ragg::agg_png(
    file.path(outdir, paste0(stem, ".png")),
    width = width_in, height = height_in, units = "in", res = 300,
    background = "white"
  )
  print(plot)
  dev.off()

  ragg::agg_tiff(
    file.path(outdir, paste0(stem, ".tiff")),
    width = width_in, height = height_in, units = "in", res = dpi,
    compression = "lzw", background = "white"
  )
  print(plot)
  dev.off()
}

save_figure(main_figure, "Figure4_strict_qc_unified")

write.csv(
  data.frame(
    panel = c("4a", "4b", "4c", "4d", "4e", "4f"),
    content = c(
      "Human TMJ bulk sample-level seven-gene expression",
      "Strict-QC human joint single-cell atlas",
      "Strict-QC donor-aware lollipop and condition-share display",
      "Strict-QC donor-equal seven-gene localization heatmap",
      "Strict-QC donor-level context-matched pseudobulk expression",
      "MR, strict-QC scRNA and TMJ bulk evidence matrix"
    ),
    replicate_unit = c(
      "independent tissue sample", "cell; visualization only",
      "donor-first descriptive aggregate", "donor-first descriptive aggregate",
      "independent donor", "donor/sample summary"
    ),
    source_workflow = c(
      "GSE205389", rep("GSE216651 strict QC (32,153 singlets)", 4),
      "MR plus GSE216651 strict QC plus GSE205389"
    )
  ),
  file.path(outdir, "figure_panel_manifest.csv"), row.names = FALSE
)

writeLines(
  c(
    "Figure 4 | Human transcriptomic context for seven prioritized genes.",
    "a, Sample-level expression of the seven genes in human TMJ synovium from five TMJOA samples and five reducible disc-displacement controls. Each point is an independent sample; q values are exact two-sided permutation P values adjusted across seven genes by the Benjamini-Hochberg method.",
    "b, UMAP of 32,153 singlets retained after one strict quality-control workflow from three healthy and three OA human joint donors, coloured by broad cell class; cells are visualization units only.",
    "c, Donor-aware cell-context summary from the same strict-QC workflow. The upper lollipop plot shows mean log-normalized expression calculated first within donor and cell context and then equally averaged across available donors. The lower bars show condition shares derived from within-donor cell fractions and are descriptive rather than differential-abundance tests.",
    "d, Donor-equal localization heatmap for the seven genes across eight reproducibly annotated cell contexts from the strict-QC workflow. Colours are z-scores calculated within each gene. One OA donor had no FCN1-monocyte cells; no expression value was imputed.",
    "e, Donor-level pseudobulk expression in prespecified contexts from the same strict-QC workflow. Points are independent donors, horizontal bars are group means, and displayed P values are exact two-sided donor-label permutation tests. NE denotes not estimable.",
    "f, Direction-and-evidence summary across MR, matched single-cell RNA sequencing and human TMJ bulk expression. Bubble colour denotes relation to the MR direction, bubble size reflects within-column statistical evidence for the expression datasets, black outlines and asterisks denote exact BH-FDR < 0.05, and values are signed effects. MR bubbles have a fixed reference size because an MR P value is not encoded in this panel."
  ),
  file.path(outdir, "proposed_figure_legend.txt")
)

writeLines(
  c(
    "Core conclusion: independent human TMJ tissue expression is followed by strict-QC human joint cellular localization and donor-level contextual support for the seven prioritized genes.",
    "Archetype: asymmetric mixed-modality quantitative grid.",
    "Backend: R only for drawing, preview and export.",
    "Panel A source: GSE205389, five independent TMJOA samples and five reducible disc-displacement controls.",
    "Panels B-F single-cell source: one GSE216651 strict-QC workflow retaining 32,153 singlets from three healthy and three OA donors.",
    "Strict thresholds: at least 400 detected genes, at least 3,000 UMIs and at most 10% mitochondrial reads; Scrublet run per donor.",
    paste0("Panel B displays all ", nrow(atlas), " strict-QC singlets; cells are not treated as biological replicates."),
    "Panel B visibility revision: only the categorical palette saturation, point size and point opacity were increased; coordinates, cells, labels and all downstream analyses are unchanged.",
    "Panels C-D use eight reproducibly annotated contexts. A separate Mast context was not retained because it was not supported as a stable broad class under strict QC; 277 explicitly identified immune-contaminant cells were excluded from context summaries.",
    "Panel C is descriptive and does not claim differential abundance.",
    "Panel D averages donor-context expression without imputing zero expression for a donor with zero cells in that context.",
    paste0("Panel E displays ", sum(is.finite(donor$log2_cpm)), " finite donor pseudobulk values; the unavailable H1F0 OA donor was not imputed."),
    "Panel E inference uses donors as biological replicates and exact two-sided 3-vs-3 label permutation tests; seven-gene BH-FDR values are retained in source data.",
    "Panel F is a synthesis and adds no new inferential test.",
    "No result was filtered on effect direction or statistical significance.",
    "Static-source warning review: the 190-mm width is intentional because the author requested a wider two-column composite; the uncertainty warning is a lexical false positive caused by reproducible jitter seeds and descriptive mean labels, not by unreported stochastic aggregates.",
    "Typography audit: every explicit SVG text run is at least 5.00 pt and panel tags are embedded as Times New Roman. The generic PDF Tf scanner reports 1 pt because the R PDF device applies text-matrix scaling; final-size SVG and PNG inspection was therefore used for the glyph-floor check.",
    "Export contract: 190 x 220 mm; editable PDF/SVG; 300-dpi PNG; 600-dpi LZW TIFF."
  ),
  file.path(outdir, "figure_contract_and_qa_notes.txt")
)

message("Created unified strict-QC Figure 4 in: ", outdir)
